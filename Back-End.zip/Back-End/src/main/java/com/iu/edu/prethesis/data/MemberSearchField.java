package com.iu.edu.prethesis.data;

/**
 * Created by Vo on 2/3/2017.
 */
public enum   MemberSearchField{

    NAME ("name"),

    LOCATION ("location"),

    EMAIL ("email"),

    CODE ("code");

    private  String literal;

    MemberSearchField(String literal) {
        this.literal = literal;
    }

    public String getLiteral() {
        return literal;
    }

    public void setLiteral(String literal) {
        this.literal = literal;
    }
}
