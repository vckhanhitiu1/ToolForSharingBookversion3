package com.iu.edu.prethesis.technical;

import com.iu.edu.prethesis.data.BookOwnerOrderField;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.SortCriteria;
import com.iu.edu.prethesis.data.bom.BookOwner;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Created by khanhvo on 6/18/17.
 */

public class BookOwnerComparator implements Comparator<BookOwner> {

    private SortByCriteria sortByCriteria;

    public BookOwnerComparator(SortByCriteria sortByCriteria)
    {
        this.sortByCriteria =sortByCriteria;
    }

    @Override
    public int compare(BookOwner thiz, BookOwner that) {
        if (sortByCriteria == null || sortByCriteria.getOrder() == null || sortByCriteria.getOrder().isEmpty()) {
            return thiz.getIsbn().compareTo(that.getIsbn());
        } else {
            List<SortCriteria> copiedOnes = new ArrayList<SortCriteria>(sortByCriteria.getOrder());
            return compare(thiz, that, copiedOnes);
        }
    }

    public int compare(BookOwner thiz, BookOwner that, List<SortCriteria> orderCriterias) {
        SortCriteria orderCriteria = orderCriterias.remove(0);
        int result = compare(thiz, that, orderCriteria);

        if (orderCriterias.isEmpty()) {
            return result;
        }

        if (result != 0) {
            return result;
        } else {
            return compare(thiz, that, orderCriterias);
        }
    }

    public int compare(BookOwner thiz, BookOwner that, SortCriteria orderCriteria) {
        if (BookOwnerOrderField.BOOK_NAME.getLiteral().equalsIgnoreCase(orderCriteria.getField())) {
            if (orderCriteria.isDescending()) {
                return that.getBookname().compareTo(thiz.getBookname());
            } else return thiz.getBookname().compareTo(thiz.getBookname());
        }

        if (BookOwnerOrderField.ISBN.getLiteral().equalsIgnoreCase(orderCriteria.getField())) {
            if (orderCriteria.isDescending()) {
                return that.getIsbn().compareTo(thiz.getIsbn());
            }
            else
            {
                return thiz.getIsbn().compareTo(that.getBookname());
            }
        }
        else
           throw new UnsupportedOperationException();


    }
}
