package com.iu.edu.prethesis.data.authorsInfor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.entity.AuthorsEntity;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vo on 2/6/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Authors implements Serializable{

    private Integer id;

    @NotNull
    private String firstname;

    @NotNull
    private String lastname;

    @NotNull
    private Integer bookId;

    public Authors(Integer id, String firstname, String lastname, Integer bookId) {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.bookId = bookId;
    }


    public static Authors fromEntity(AuthorsEntity entity)
    {
        if(entity==null)
        {
            return null;
        }
        Authors bom = new Authors();
        bom.setFirstname(entity.getFirstname());
        bom.setLastname(entity.getLastname());
        return bom;
    }
    public static List<Authors> ChangeFromListAuthorEntityToAuthors(List<AuthorsEntity> authorsEntities)
    {
        List<Authors> authorss = new ArrayList<>();
        Authors authors = new Authors();
        for (AuthorsEntity authorsEntity: authorsEntities) {
            authors.fromEntity(authorsEntity);
            authorss.add(authors);
        }
        return authorss;
    }

    public Authors() {
        //Empty Constructor
    }

    

    public Integer getId() {
        return id;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }


    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Authors authors = (Authors) o;

        if (id != null ? !id.equals(authors.id) : authors.id != null) return false;
        if (firstname != null ? !firstname.equals(authors.firstname) : authors.firstname != null) return false;
        return lastname != null ? lastname.equals(authors.lastname) : authors.lastname == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (firstname != null ? firstname.hashCode() : 0);
        result = 31 * result + (lastname != null ? lastname.hashCode() : 0);
        return result;
    }
}
