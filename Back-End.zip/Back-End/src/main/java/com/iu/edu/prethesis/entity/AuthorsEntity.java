package com.iu.edu.prethesis.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.iu.edu.prethesis.data.authorsInfor.Authors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vo on 2/6/2017.
 */
@SuppressWarnings("serial")
@Entity
@Table(name="authors")
@NamedQueries({
        @NamedQuery(name= AuthorsEntity.FIND_ALL, query = "SELECT a FROM AuthorsEntity a"),
        @NamedQuery(name= AuthorsEntity.FIND_BY_BOOK_ID, query = "SELECT b FROM  AuthorsEntity b WHERE b.bookId = :bookId")

})

public class AuthorsEntity extends GenericEntity implements Serializable{

    private static final String PREFIX = "com.iu.edu.prethesis.entity.AuthorsEntity";

    public static final String FIND_ALL = PREFIX + ".findAll";

    public static final String FIND_BY_BOOK_ID = PREFIX + ".findByBookId";

    @Column(name="firstname", nullable = false)
    private String firstname;

    @Column(name="lastname", nullable = false)
    private String lastname;

    @Column(name="book_id")
    private Integer bookId;


    public AuthorsEntity() {
    }

    public AuthorsEntity(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public AuthorsEntity(String firstname, String lastname, Integer bookId) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.bookId = bookId;
    }

    public static final Logger logger = LoggerFactory.getLogger(AuthorsEntity.class);

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        AuthorsEntity that = (AuthorsEntity) o;

        if (!firstname.equals(that.firstname)) return false;
        return lastname.equals(that.lastname);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + firstname.hashCode();
        result = 31 * result + lastname.hashCode();
        return result;
    }
    public static AuthorsEntity fromBom(Authors bom)
    {
        if(bom==null)
        {
            return null;
        }
        AuthorsEntity authorsEntity = new AuthorsEntity();
               authorsEntity.setFirstname(bom.getFirstname());
               authorsEntity.setLastname(bom.getLastname());
        return  authorsEntity;
    }

    public static List<AuthorsEntity> ChangeFromListAuthorToAuthorsEntity(List<Authors> authorss)
    {
        List<AuthorsEntity> authorsEntities = new ArrayList<>();
        AuthorsEntity authorsEntity = new AuthorsEntity();
        for (Authors authors: authorss) {
            authorsEntity.fromBom(authors);
            authorsEntities.add(authorsEntity);
        }
        return authorsEntities;
    }

}

