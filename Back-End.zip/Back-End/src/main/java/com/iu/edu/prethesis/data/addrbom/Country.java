package com.iu.edu.prethesis.data.addrbom;

import java.io.Serializable;

public class Country implements Serializable {


    /*
     *
     */
    private Integer id;

    /*
     *
     */
    private String name;

    /*
     *
     */
    private String isoAlpha2;


    public Country() {

    }


    public Country(Integer id, String name, String isoAlpha2) {
        super();
        this.id = id;
        this.name = name;
        this.isoAlpha2 = isoAlpha2;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIsoAlpha2() {
        return isoAlpha2;
    }

    public void setIsoAlpha2(String isoAlpha2) {
        this.isoAlpha2 = isoAlpha2;
    }

    @Override
    public String toString() {
        return "Country [id=" + id + ", name=" + name + ", isoAlpha2=" + isoAlpha2 + "]";
    }


}
