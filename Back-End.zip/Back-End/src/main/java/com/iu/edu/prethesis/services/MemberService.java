package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.bom.Member;
import com.iu.edu.prethesis.entity.AddressEntity;
import com.iu.edu.prethesis.entity.MemberEntity;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.validation.Valid;
import java.util.List;

@Stateless
public class MemberService extends GenericService<MemberEntity, Member> {

    @EJB
    AddressService addressService;

    @EJB
    BookService bookService;

    @EJB
    OwnBookService ownBookService;

    public MemberService() {
        super(MemberEntity.class);
    }

    public List<MemberEntity> findAll() {
        TypedQuery<MemberEntity> query = em.createNamedQuery(MemberEntity.FIND_ALL, MemberEntity.class);
        return query.getResultList();
    }

    public MemberEntity findByCode(String accountCode)
    {
        TypedQuery<MemberEntity> query = em.createNamedQuery(MemberEntity.FIND_BY_CODE, MemberEntity.class);
        query.setParameter("accountCode", accountCode);
        List<MemberEntity> results = query.getResultList();
        if(results.isEmpty())
            return null;
        return  results.get(0);
    }

    public void save(@Valid Member member) {
        MemberEntity previousMemberEntity = this.findByCode(member.getAccountCode());
        MemberEntity currentMemberEntity = this.toEntity(member);

        if(previousMemberEntity!=null && previousMemberEntity.getAccountCode().equals(currentMemberEntity.getAccountCode())) {
            currentMemberEntity.setId(previousMemberEntity.getId());
            this.save(currentMemberEntity);
            member.setId(currentMemberEntity.getId());
        }
        else
        {
            this.save(currentMemberEntity);
            member.setId(currentMemberEntity.getId());
        }
        if(member.getAddress()!=null) {
            member.getAddress().setMemberId(member.getId());
            addressService.save(member.getAddress());
        }
        if (member.getOwnBooks() != null) {
                member.getOwnBooks().setMemberId(member.getId());
                ownBookService.saveBelongtoMemberId(member.getOwnBooks());
        }

    }


    public boolean isSame(MemberEntity previousEntity, MemberEntity currentEntity)
    {
        return previousEntity.getAccountCode().equals(currentEntity.getAccountCode())&&
                previousEntity.getEmailAddress().equals(currentEntity.getAccountCode())&&
                previousEntity.getPhoneNr().equals(currentEntity.getPhoneNr());
   }


//            if(member.getBooks()!=null)
//            {
//                for(Book book: member.getBooks())
//                {
//                    if(member.getBookOwners()!=null) {
//                        for (BookOwner bookOwner : member.getBookOwners()) {
//                            List<Member> members = new ArrayList <>();
//                            members.add(member);
//                            book.setId(bookOwner.getBookId());
//                            book.setMembers(members);
//                            bookService.save(book);
//                        }
//
//                    }
//
//
//
//                }
//        }
//
//        this.save(memberEntity);
//    }

    @Override
    public MemberEntity toEntity(Member bom) {
        if (bom == null) {
            return null;
        }

        MemberEntity entity = new MemberEntity();
        entity.setId(bom.getId());
        entity.setName(bom.getName());
        entity.setPhoneNr(bom.getPhoneNr());
        entity.setEmailAddress(bom.getEmailAddress());
        entity.setImage(bom.getImage());
        entity.setAccountCode(bom.getAccountCode());
//        entity.setBookEntities(BookEntity.ChangeFromListBookToBookEntity(bom.getBooks()));
        return entity;
    }

    @Override
    public Member toBom(MemberEntity entity) {
        if (entity == null) {
            return null;
        }
        Member bom = new Member();

        bom.setName(entity.getName());
        bom.setPhoneNr(entity.getPhoneNr());
        AddressEntity address = this.addressService.findByMemberId(entity.getId());
        bom.setAddress(this.addressService.toBom(address));
        bom.setEmailAddress(entity.getEmailAddress());
        bom.setImage(entity.getImage());
        bom.setAccountCode(entity.getAccountCode());

        return bom;
    }

}
