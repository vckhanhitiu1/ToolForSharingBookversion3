package com.iu.edu.prethesis.entity;

import com.iu.edu.prethesis.data.bom.BookType;
import com.iu.edu.prethesis.data.bom.Status;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by khanhvo on 6/27/17.
 */
@Entity
@Table(name = "book_ocr")

@NamedQueries({
        @NamedQuery(name = BookOCREntity.FIND_ALL, query = "SELECT b FROM BookOCREntity b"),
})
public class BookOCREntity extends GenericEntity{

    private static final String PREFIX = "com.iu.edu.prethesis.entity.BookOCREntity";

    public static final String FIND_ALL = PREFIX + ".findAll";

    @Column(name = "isbn" ,nullable = false)
    private String isbn;

    @Column(name = "book_name", nullable = false)
    private String bookname;


    @Lob
    @Column(name = "image")
    private byte[] image;

    @Column(name = "price")
    private Float price;

    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "copyright")
    private Date copyright;

    @Column(name = "edition")
    private Integer edition;

    @Column(name = "booktype", nullable = false)
    private BookType booktype;

    @Column(name = "status", nullable = false)
    private Status status;

    @Column(name="authors")
    private String authors;

    @Column(name = "own_book_id")
    private Integer ownbookid;


    public BookOCREntity() {
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCopyright() {
        return copyright;
    }

    public void setCopyright(Date copyright) {
        this.copyright = copyright;
    }

    public Integer getEdition() {
        return edition;
    }

    public void setEdition(Integer edition) {
        this.edition = edition;
    }

    public BookType getBooktype() {
        return booktype;
    }

    public void setBooktype(BookType booktype) {
        this.booktype = booktype;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public Integer getOwnbookid() {
        return ownbookid;
    }

    public void setOwnbookid(Integer ownbookid) {
        this.ownbookid = ownbookid;
    }
}
