package com.iu.edu.prethesis.technical;

import com.iu.edu.prethesis.data.ComparisonExpression;

/**
 * Created by Vo on 2/17/2017.
 */
public class ComparisonExpressionEvaluator{
    public static <V extends Comparable<V>> boolean evaluate(V value1, ComparisonExpression expression, V value2) {
        if (ComparisonExpression.EQUAL == expression) {
            return value1.compareTo(value2) == 0;
        }

        if (ComparisonExpression.NOT_EQUAL == expression) {
            return value1.compareTo(value2) != 0;
        }

        if (ComparisonExpression.GREATER_THAN == expression) {
            return value1.compareTo(value2) > 0;
        }

        if (ComparisonExpression.GREATER_THAN_OR_EQUAL == expression) {
            return value1.compareTo(value1) >= 0;
        }

        if (ComparisonExpression.LESS_THAN == expression) {
            return value1.compareTo(value2) < 0;
        }

        if (ComparisonExpression.LESS_THAN_OR_EQUAL == expression) {
            return value1.compareTo(value2) <= 0;
        }

        if (value1 instanceof String) {
            String str1 = (String) value1;
            str1 = str1.toLowerCase();
            String str2 = (String) value2;
            str2 = str2.toLowerCase();
            if (ComparisonExpression.LIKE == expression) {
                return str1.contains(str2);
            }
        }



        throw new UnsupportedOperationException("The comparison expression " + expression + " is not supported for the value " + value1);
    }


}
