package com.iu.edu.prethesis.data.bom;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Book implements Serializable {

    /*
     *
     */
    private Integer id;

    @NotNull
    @Pattern(regexp = "^(97(8|9))?\\d{9}(\\d|X)$", message = "{Invalid ISBN}")
    private String isbn;
    /*
     *
     */
    @NotNull
    @Size(max = 30, min = 1)
    private String bookname;

    /**
     *
     */
//    @Pattern(regexp = "([^\\s]+(\\.(?i)(jpg|png|gif|bmp))$)", message = "{not an image}")
    private String image;

    /*
     *
     */
    @DecimalMax("200.0")
    private Float price;

    /*
     *
     */
    @NotNull
    private String description;
    /*
     *
     */
    @NotNull
    private Date copyright;

    /*
     *
     */

    private Integer edition;

    /*
     *
     */
    @NotNull
    private BookType booktype;

    /*
     *
     */
    @NotNull
    private Status status;

    /**
     *
     */
    @NotNull
//    private List<Authors> authors;
    private String authors;


    private Integer ownbookid;

    public Book(String bookname, Float price, String description, Date copyright, Integer edition, BookType booktype, Status status, String authors) {
        this.bookname = bookname;
        this.price = price;
        this.description = description;
        this.copyright = copyright;
        this.edition = edition;
        this.booktype = booktype;
        this.status = status;
        this.authors = authors;
    }

    public Book(Integer id, String isbn, String bookname, String image, Float price, String description, Date copyright, Integer edition, BookType booktype, Status status, String authors) {
        this.id = id;
        this.isbn = isbn;
        this.bookname = bookname;
        this.image = image;
        this.price = price;
        this.description = description;
        this.copyright = copyright;
        this.edition = edition;
        this.booktype = booktype;
        this.status = status;
        this.authors = authors;
    }

    public Book() {

    }






    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", isbn='" + isbn + '\'' +
                ", bookname='" + bookname + '\'' +
                ", price=" + price +
                ", description='" + description + '\'' +
                ", copyright=" + copyright +
                ", edition=" + edition +
                ", booktype=" + booktype +
                ", status=" + status +
                '}';
    }


    public Integer getOwnbookid() {
        return ownbookid;
    }

    public void setOwnbookid(Integer ownbookid) {
        this.ownbookid = ownbookid;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIsbn() {
        return isbn;
    }


    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }


    public String getBookname() {
        return bookname;
    }


    public void setBookname(String bookname) {
        this.bookname = bookname;
    }


    public Float getPrice() {
        return price;
    }


    public void setPrice(Float price) {
        this.price = price;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public Date getCopyright() {
        return copyright;
    }


    public void setCopyright(Date copyright) {
        this.copyright = copyright;
    }


    public Integer getEdition() {
        return edition;
    }


    public void setEdition(Integer edition) {
        this.edition = edition;
    }


    public BookType getBooktype() {
        return booktype;
    }


    public void setBooktype(BookType booktype) {
        this.booktype = booktype;
    }


    public Status getStatus() {
        return status;
    }


    public void setStatus(Status status) {
        this.status = status;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Book book = (Book) o;

        if (id != null ? !id.equals(book.id) : book.id != null) return false;
        if (isbn != null ? !isbn.equals(book.isbn) : book.isbn != null) return false;
        if (bookname != null ? !bookname.equals(book.bookname) : book.bookname != null) return false;
        if (image != null ? !image.equals(book.image) : book.image != null) return false;
        if (price != null ? !price.equals(book.price) : book.price != null) return false;
        if (description != null ? !description.equals(book.description) : book.description != null) return false;
        if (copyright != null ? !copyright.equals(book.copyright) : book.copyright != null) return false;
        if (edition != null ? !edition.equals(book.edition) : book.edition != null) return false;
        if (booktype != book.booktype) return false;
        if (status != book.status) return false;
        return authors != null ? authors.equals(book.authors) : book.authors == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (isbn != null ? isbn.hashCode() : 0);
        result = 31 * result + (bookname != null ? bookname.hashCode() : 0);
        result = 31 * result + (image != null ? image.hashCode() : 0);
        result = 31 * result + (price != null ? price.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (copyright != null ? copyright.hashCode() : 0);
        result = 31 * result + (edition != null ? edition.hashCode() : 0);
        result = 31 * result + (booktype != null ? booktype.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (authors != null ? authors.hashCode() : 0);
        return result;
    }
}
