package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.BookOCR;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.BookOCREntity;
import com.iu.edu.prethesis.services.BookOCRService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.io.IOException;
import java.net.URI;
import java.util.List;

/**
 * Created by khanhvo on 6/27/17.
 */
@Stateless
@Path(value = "/bookocr")
public class BookOCRResource {
    @Context
    private UriInfo uriInfo;

    @PersistenceContext(name = "thesisprojectPU")
    private EntityManager em;

    @EJB
    BookOCRService bookOCRService;

    @POST
    @Consumes(value = MediaType.APPLICATION_JSON)
    @Produces(value = MediaType.APPLICATION_JSON)
    public Response creatBook(@Valid BookOCR bookOCR) throws IOException {
        bookOCRService.save(bookOCR);
        URI bookUri = uriInfo.getAbsolutePathBuilder().path(bookOCR.getId().toString()).build();
        return Response.created(bookUri).build();
    }

    @GET
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON})
    public List<BookOCREntity> getAll() {

        return bookOCRService.findAll();
    }





}
