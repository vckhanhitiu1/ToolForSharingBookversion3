package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.BookOCR;
import com.iu.edu.prethesis.data.ocr.OCRResponseJSONBody;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.BookOCREntity;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.validation.Path;
import javax.validation.Valid;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

/**
 * Created by khanhvo on 6/27/17.
 */
@Stateless
public class BookOCRService  extends GenericService<BookOCREntity,BookOCR>
{

    private final static String SUBSCRIPTION_ID = "8d17516bfd4a43b49b8612f5fb932fa6";



    public BookOCRService() {
        super(BookOCREntity.class);
    }

    OCRService ocrService = new OCRService(SUBSCRIPTION_ID);


    public String getTheContentOfImageISBN(String isbnURI) throws IOException {

        Optional<com.iu.edu.prethesis.services.OCRResponseJSONBody> result = ocrService.getOCRAnalysisResult(Paths.get(isbnURI));
           result.ifPresent(resultbody-> ocrService.getOCRResult(resultbody));
                return  ocrService.getOCRResult(result.get());

    }

    public String getTheContentOfImageBookName(String booknameURI) throws IOException {

        Optional<com.iu.edu.prethesis.services.OCRResponseJSONBody> result = ocrService.getOCRAnalysisResult(Paths.get(booknameURI));
        result.ifPresent(resultbody-> ocrService.getOCRResult(resultbody));
        return  ocrService.getOCRResult(result.get());


    }
    public void save(@Valid BookOCR bookOCR) throws IOException {
        BookOCREntity currentBookOcrEntity = this.toEntity(bookOCR);
        this.save(currentBookOcrEntity);
        bookOCR.setId(currentBookOcrEntity.getId());

    }

    public List<BookOCREntity> findAll()
    {
        TypedQuery<BookOCREntity> query = em.createNamedQuery(BookOCREntity.FIND_ALL, BookOCREntity.class);
        return query.getResultList();
    }

    @Override
    public BookOCREntity toEntity(BookOCR bom) throws IOException {
        if (bom == null) {
            return null;
        }
        BookOCREntity entity = new BookOCREntity();

        entity.setIsbn(this.getTheContentOfImageISBN(bom.getIsbn()));
        entity.setBookname(this.getTheContentOfImageBookName(bom.getBookname()));
        entity.setPrice(bom.getPrice());
        entity.setImage(BookEntity.changeFromStringTypeToByteType(bom.getImage()));
        entity.setDescription(bom.getDescription());
        entity.setCopyright(bom.getCopyright());
        entity.setEdition(bom.getEdition());
        entity.setBooktype(bom.getBooktype());
        entity.setStatus(bom.getStatus());
        entity.setAuthors(bom.getAuthors());
        entity.setOwnbookid(bom.getOwnbookid());
        return entity;    }

    @Override
    public BookOCR toBom(BookOCREntity entity) {
//        if (entity == null) {
//            return null;
//        }
//        BookOCR bom = new BookOCR();
//
//        bom.setId(entity.getId());
//        bom.setIsbn(BookEntity.changeFromByteTypeToStringType(entity.getIsbn()));
//        bom.setBookname(BookEntity.changeFromByteTypeToStringType(entity.getBookname()));
//        bom.setPrice(entity.getPrice());
//        bom.setImage(BookEntity.changeFromByteTypeToStringType(entity.getImage()));
//        bom.setDescription(entity.getDescription());
//        bom.setCopyright(entity.getCopyright());
//        bom.setEdition(entity.getEdition());
//        bom.setBooktype(entity.getBooktype());
//        bom.setStatus(entity.getStatus());
//        bom.setAuthors(entity.getAuthors());
//        bom.setOwnbookid(entity.getOwnbookid());
//        return bom;
        return null;

}
}
