package com.iu.edu.prethesis.data.bom;

public enum BookType {
    SCIENCE,
    ACTION,
    ROMANCE,
    HORROR,
    MYSTERY

}
