package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.RangeCriteria;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.BookType;
import com.iu.edu.prethesis.data.bom.Status;
import com.iu.edu.prethesis.entity.BookEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityNotFoundException;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;

/**
 * Created by Vo on 3/6/2017.
 */
@Stateless
public class BookFacade{

    @EJB
    BookService bookService;

    @EJB
    BookCacheService bookCacheService;

    @EJB
    MessageService messageService;

    private static final Logger logger = LoggerFactory.getLogger(BookFacade.class);

    public void save(Book book)
    {
        bookService.save(book);
        bookCacheService.put(book.getIsbn(),book);

    }

    public Book readBookByISBN(String isbn)
    {
        Book book = this.bookCacheService.get(isbn);
        if(book==null)
        {
            throw new EntityNotFoundException("The ISBN does not exist");
        }
        return book;

    }

    public List<Book> search(SearchByCriteria searchBy, SortByCriteria sortBy , RangeCriteria range)
    {
        if(this.bookCacheService.values().isEmpty())
        {
            InitDataIntoCache();
        }
         return    this.bookCacheService.search(searchBy,sortBy,range);

    }

    public void InitDataIntoCache()
    {
        List<BookEntity> entities = this.bookService.findAll();
        this.bookCacheService.clearAll();
        entities.forEach(new Consumer<BookEntity>(){
            @Override
            public void accept(BookEntity entity) {
                BookFacade.this.bookCacheService.put(entity.getIsbn(), BookFacade.this.bookService.toBom(entity));
            }
        });
        logger.info("initialize cache successfully!!!");
        logger.info("there're " + entities.size()+ " item(s) initialized in cache");

    }

    public void updateBookInfoByISBN(String isbn, String bookname
            , String authors, Date copyright, Integer edition,String description,
                                     BookType bookType, Status status,float price)
    {
        Book book = this.bookCacheService.get(isbn);
        if(book!=null) {
            throw new EntityNotFoundException("The Book does not exist");
        }
        book.setBookname(bookname);
        book.setAuthors(authors);
        book.setPrice(price);
        book.setDescription(description);
        book.setCopyright(copyright);
        book.setEdition(edition);
        book.setBooktype(bookType);
        book.setStatus(status);
        this.bookCacheService.put(book.getIsbn(),book);
        bookService.updateBookInfoByISBN(book);
    }

}
