package com.iu.edu.prethesis.services;


import com.iu.edu.prethesis.technical.interceptor.RequestMetadata;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.text.MessageFormat;


/**
 * Created by Vo on 2/1/2017.
 */
@Stateless
public class MessageService extends AbstractResourceService{

    @Inject
    public RequestMetadata requestMetadata;

    public MessageService()
    {
        bundleName="com.iu.edu.prethesis.resources.i18.messages";
    }
    protected String get(String errorCode)
    {
        String val =super.get(errorCode,requestMetadata.getLocale());
        return appendErrorCode(errorCode,val);
    }

    private String appendErrorCode(String errorCode, String val)
    {
        return errorCode + " - "+ val;
    }

    public String get(String key, Object... params)
    {
        return MessageFormat.format(get(key),params);
    }

    public String get(ErrorCode errorCode) {
        return get(errorCode.getErrorCode());
    }


    public String get(ErrorCode errorCode, Object... params) {
        return get(errorCode.getErrorCode(), params);
    }

    public enum ErrorCode
    {

        RESOURCE_BUNDLE_MISSING("SFER301"),

        MEMBER_CODE_NULL("SFER404"),

        MEMBER_NOT_EXIST("SFER104"),
        BOOK_NOT_EXIST("SFER105");


        private final String errorCode;

        ErrorCode(String error) {
            this.errorCode = error;
        }

        public String getErrorCode() {
            return errorCode;
        }
    }




}
