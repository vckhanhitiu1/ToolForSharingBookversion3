package com.iu.edu.prethesis.entity;

import javax.persistence.*;
import java.io.Serializable;

@SuppressWarnings("serial")
@Entity
@Table(name = "members")
@NamedQueries(
        {
                @NamedQuery(name = MemberEntity.FIND_ALL, query = "SELECT m FROM MemberEntity m"),
                @NamedQuery(name =MemberEntity.FIND_BY_CODE, query = "SELECT c FROM MemberEntity c WHERE c.accountCode = :accountCode")
        })
public class MemberEntity extends GenericEntity implements Serializable {

    private static final String PREFIX = "com.iu.edu.sharingbook.entity.MemberEntity";

    public static final String FIND_ALL = PREFIX + ".findAll";

    public static final String FIND_BY_CODE = PREFIX +".findByCode";

    @Column(name = "member_name", nullable = false, length = 30)
    private String name;

    @Column(name = "phone_number", nullable = false, length = 20)
    private String phoneNr;

    @Column(name = "email_address", nullable = false)
    private String emailAddress;

    @Column(name = "image_string")
    private String image;

    @Column(name = "accountCode",nullable = false , length = 15)
    private String accountCode;

//
//    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
//    @JoinTable(name="member_book",
//            joinColumns=
//            @JoinColumn(name="member_id", referencedColumnName="ID"),
//            inverseJoinColumns=
//            @JoinColumn(name="book_id", referencedColumnName="ID")
//    )
//    private List<BookEntity> bookEntities;


    public MemberEntity() {

    }

    public MemberEntity(String name, String phoneNr, String emailAddress, String image, String accountCode) {
        this.name = name;
        this.phoneNr = phoneNr;
        this.emailAddress = emailAddress;
        this.image = image;
        this.accountCode = accountCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNr() {
        return phoneNr;
    }

    public void setPhoneNr(String phoneNr) {
        this.phoneNr = phoneNr;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getAccountCode() {
        return accountCode;
    }

    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    @Override
    public String toString() {
        return "MemberEntity [name=" + name + ", phoneNr=" + phoneNr  + ", emailAddress="
                + emailAddress + ", image=" + image + ", accountCode=" + accountCode + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();

        result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
        result = prime * result + ((image == null) ? 0 : image.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((phoneNr == null) ? 0 : phoneNr.hashCode());

        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        MemberEntity other = (MemberEntity) obj;

        if (emailAddress == null) {
            if (other.emailAddress != null)
                return false;
        } else if (!emailAddress.equals(other.emailAddress))
            return false;
        if (image == null) {
            if (other.image != null)
                return false;
        } else if (!image.equals(other.image))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (phoneNr == null) {
            if (other.phoneNr != null)
                return false;
        } else if (!phoneNr.equals(other.phoneNr))
            return false;

        return true;
    }


}
