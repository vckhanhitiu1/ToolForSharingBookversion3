package com.iu.edu.prethesis.data.authbom;

/**
 * Created by Vo on 3/25/2017.
 */
public class Permission {
}
