package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.OwnBooks;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.OwnBookEntity;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.validation.Valid;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Created by Vo on 5/7/2017.
 */
@Stateless
public class OwnBookService extends  GenericService<OwnBookEntity,OwnBooks>
{

    @EJB
    BookService bookService;

    @EJB
    BookFacade bookFacade;

    public OwnBookService() {
        super(OwnBookEntity.class);
    }



    public void saveBelongtoMemberId(@Valid OwnBooks ownBooks)
  {
         OwnBookEntity currentOwnBookEntity = this.toEntity(ownBooks);
         List<OwnBookEntity> ownBookEntityList =
                 this.findListOwnBookByMemberId(ownBooks.getMemberId());

             if(ownBookEntityList!=null) {
                 for (OwnBookEntity ownBookEntity : ownBookEntityList) {
                     if (ownBookEntity.getMemberId().equals(currentOwnBookEntity.getMemberId())) {
                         BookEntity bookEntity = bookService.findByOwnBookId(ownBookEntity.getId());

                         Book book = bookService.toBom(bookEntity);
                         if (book != null) {
                             if (this.isUniqueBook(book, ownBooks.getBooks()) == true) {
                                 ownBooks.getBooks().add(book);
                                 bookFacade.save(book);
                                 book.setOwnbookid(ownBookEntity.getId());
                                 book.setId(bookEntity.getId());
                                 book.setImage(BookEntity.changeFromByteTypeToStringType(bookEntity.getImage()));
                             }


                         }
                     }
                 }
             }
             this.save(currentOwnBookEntity);
             ownBooks.setId(currentOwnBookEntity.getId());


             if (ownBooks.getBooks() != null) {
                 for (Book book : ownBooks.getBooks()) {
                     book.setOwnbookid(ownBooks.getId());

                     bookFacade.save(book);

                 }

             }


    }

    public boolean isUniqueBook(Book book, List<Book> books)
    {
        boolean result= false;
        for(Book book1 : books)
        {
            if(book.getIsbn()!= book1.getIsbn())
            {
                result = true;
            }
            else return false;
        }
        return  result;
    }


//    public OwnBookEntity findByBookId(Integer bookId)
//    {
//        TypedQuery<OwnBookEntity> query = em.createNamedQuery(OwnBookEntity.FIND_BY_BOOK_ID, OwnBookEntity.class);
//        query.setParameter("bookId",bookId);
//        List<OwnBookEntity> results = query.getResultList();
//        if(results.isEmpty())
//            return null;
//        return  results.get(0);
//    }

    public boolean isSame(OwnBookEntity previousEntity, OwnBookEntity currentEntity)
    {
        return Objects.equals(previousEntity.getMemberId(),currentEntity.getMemberId());
    }

    public OwnBookEntity findByMemberId(Integer memberId)
    {

        TypedQuery<OwnBookEntity> query = em.createNamedQuery(OwnBookEntity.FIND_BY_MEMBER_ID, OwnBookEntity.class);
        query.setParameter("memberId",memberId);
        List<OwnBookEntity> results = query.getResultList();
        if(results.isEmpty())
            return null;
        return  results.get(0);
    }
    public List<OwnBookEntity> findListOwnBookByMemberId(Integer memberId)
    {

        TypedQuery<OwnBookEntity> query = em.createNamedQuery(OwnBookEntity.FIND_BY_MEMBER_ID, OwnBookEntity.class);
        query.setParameter("memberId",memberId);
        List<OwnBookEntity> results = query.getResultList();
        if(results.isEmpty())
            return null;
        return  results;
    }
    @Override
    public OwnBookEntity toEntity(OwnBooks bom) {
        if(bom==null)
        {
            return null;
        }
        OwnBookEntity entity = new OwnBookEntity();
        entity.setId(bom.getId());
        entity.setMemberId(bom.getMemberId());
        return entity;
    }

    @Override
    public OwnBooks toBom(OwnBookEntity entity) {
        if (entity == null) {
            return null;
        }
        return null;
    }

}
