package com.iu.edu.prethesis.data.addrbom;

import java.io.Serializable;

public class District implements Serializable {

    /*
     *
     */
    private Integer id;

    /*
     *
     */
    private String name;

    /*
     *
     */
    private String shortName;

    /*
     *
     */
    private Integer provinceId;

    public District() {

    }

    public District(Integer id, String name, String shortName, Integer provinceId) {
        super();
        this.id = id;
        this.name = name;
        this.shortName = shortName;
        this.provinceId = provinceId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    @Override
    public String toString() {
        return "District [id=" + id + ", name=" + name + ", shortName=" + shortName + ", provinceId=" + provinceId
                + "]";
    }


}
