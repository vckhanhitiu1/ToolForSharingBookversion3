package com.iu.edu.prethesis.data.bom;

/**
 * Created by Vo on 5/4/2017.
 */

import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BookOwner implements Serializable {

    @Id
    private Integer id;

    @NotNull
    private String isbn;

    @NotNull
    private String bookname;

    private List<Member> memberList;


    public BookOwner() {
    }

    public BookOwner(Integer id, String isbn, String bookname, List <Member> memberList) {
        this.id = id;
        this.isbn = isbn;
        this.bookname = bookname;
        this.memberList = memberList;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }


    public List <Member> getMemberList() {
        return memberList;
    }

    public void setMemberList(List <Member> memberList) {
        this.memberList = memberList;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }
}
