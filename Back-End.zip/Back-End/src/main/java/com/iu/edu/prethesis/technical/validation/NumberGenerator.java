package com.iu.edu.prethesis.technical.validation;

/**
 * Created by Vo on 2/27/2017.
 */
public interface NumberGenerator{
    String generateNumber();
}
