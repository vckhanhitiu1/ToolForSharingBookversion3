package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.MemberSearchField;
import com.iu.edu.prethesis.data.SearchCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.Member;
import com.iu.edu.prethesis.technical.ComparisonExpressionEvaluator;
import com.iu.edu.prethesis.technical.MemberComparator;
import com.iu.edu.prethesis.technical.cache.CacheProviderContainer;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

/**
 * Created by Vo on 3/2/2017.
 */
@Stateless
public class MemberCacheService extends GenericCacheService<String, Member> implements Serializable{

    @EJB
    CacheProviderContainer cacheProviderContainer;

    public MemberCacheService() {
    }

    @PostConstruct
    public void initCache()
    {
        setCache(cacheProviderContainer.<String,Member>getCache(Member.class));
    }

    @Override
    protected void sort(List<Member> list, SortByCriteria orderBy) {
        Collections.sort(list,new MemberComparator(orderBy));
    }
    @Override
    public Predicate<Member> createSingleSearchCondition(SearchCriteria criteria) {
        if (MemberSearchField.CODE.getLiteral().equalsIgnoreCase(criteria.getField())) {
            return s -> ComparisonExpressionEvaluator.evaluate(s.getAccountCode(), criteria.getExpression(), criteria.getValue().toString());
        }

        if (MemberSearchField.NAME.getLiteral().equalsIgnoreCase(criteria.getField())) {
            return s -> ComparisonExpressionEvaluator.evaluate(s.getName(), criteria.getExpression(), criteria.getValue().toString());
        }

        if (MemberSearchField.EMAIL.getLiteral().equalsIgnoreCase(criteria.getField())) {
            return s -> ComparisonExpressionEvaluator.evaluate(s.getEmailAddress().toString(), criteria.getExpression(), criteria.getValue().toString());
        }

        if (MemberSearchField.LOCATION.getLiteral().equalsIgnoreCase(criteria.getField())) {
            return s -> ComparisonExpressionEvaluator.evaluate(s.getAddress().toString(), criteria.getExpression(), criteria.getValue().toString());
        }
        throw new UnsupportedOperationException("The Search Field does not exist");
    }
}
