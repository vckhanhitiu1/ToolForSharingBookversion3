package com.iu.edu.prethesis.data.bom;

public enum Status {
    PHYSICALBOOK,
    SOFTBOOK

}
