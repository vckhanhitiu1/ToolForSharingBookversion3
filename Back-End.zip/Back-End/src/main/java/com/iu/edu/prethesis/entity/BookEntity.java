package com.iu.edu.prethesis.entity;


import com.iu.edu.prethesis.data.bom.BookType;
import com.iu.edu.prethesis.data.bom.Status;
import org.apache.commons.codec.binary.Base64;
import javax.persistence.*;
import java.io.*;
import java.util.Date;

@SuppressWarnings("serial")
@Entity
@Table(name = "books")

@NamedQueries(
        {
                @NamedQuery(name = BookEntity.FIND_ALL, query = "SELECT b FROM BookEntity b"),

                @NamedQuery(name=BookEntity.FIND_BY_ISBN, query ="SELECT i FROM BookEntity i  WHERE i.isbn =:isbn"),

                @NamedQuery(name=BookEntity.FIND_BY_BOOK_TYPE, query ="SELECT t FROM BookEntity t WHERE t.booktype =:booktype" ),

                @NamedQuery(name=BookEntity.FIND_BY_BOOK_STATUS, query = "SELECT s FROM BookEntity s WHERE s.status=:status"),

                @NamedQuery(name = BookEntity.FIND_BY_OWN_BOOK_ID, query = "SELECT i FROM BookEntity i WHERE i.ownbookid =:ownbookid")
        })
public class BookEntity extends GenericEntity implements Serializable {


    private static final String PREFIX = "com.iu.edu.prethesis.entity.BookEntity";

    public static final String FIND_ALL = PREFIX + ".findAll";

    public static final String FIND_BY_ISBN = PREFIX +".findByIsbn";

    public static final String FIND_BY_BOOK_TYPE =PREFIX +".findByBookType";

    public static final String FIND_BY_BOOK_STATUS =PREFIX+ ".findByBookStatus";

    public static final String FIND_BY_OWN_BOOK_ID = PREFIX + ".findByOwnBookId";


    public static final String SERVER_UPLOAD_LOCATION_FOLDER = "/Users/khanhvo/storageimage/";


    @Column(name = "isbn" ,nullable = false)
    private String isbn;

    @Column(name = "book_name", nullable = false, length = 30)
    private String bookname;


    @Lob
    @Column(name = "image")
    private byte[] image;

    @Column(name = "price")
    private Float price;

    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "copyright")
    private Date copyright;

    @Column(name = "edition")
    private Integer edition;

    @Column(name = "booktype", nullable = false)
    private BookType booktype;

    @Column(name = "status", nullable = false)
    private Status status;

    @Column(name="authors")
    private String authors;

    @Column(name = "own_book_id")
    private Integer ownbookid;
//
//    @ManyToMany(mappedBy = "bookEntities")
//    private List<MemberEntity> memberEntities;

    public BookEntity() {
        //The empty constructor
    }
    public static byte[] changeFromStringTypeToByteType(String image)
    {
        File file = new File(image);
        byte[] imageByteArray = null;
        try{
            FileInputStream imageFile  = new FileInputStream(file);
            byte imageData[] = new byte[(int) file.length()];
            imageFile.read(imageData);

            String imageDataString = encodeImage(imageData);
            imageDataString = imageDataString.replaceAll("_","/");

            imageByteArray = decodeImage(imageDataString);
            imageByteArray.toString().replaceAll("_","/");

            FileOutputStream imageOutFile = new FileOutputStream(SERVER_UPLOAD_LOCATION_FOLDER+"imageTest"+imageDataString.substring(50,60)+".jpg");

            imageOutFile.write(imageByteArray);
            imageFile.close();
            imageOutFile.close();
            System.out.println("Image Successfully Manipulated!");
        }catch (FileNotFoundException e)
        {
            System.out.println("Image Not Found" + e);
        }catch (IOException ex)
        {
            System.out.println("Exception while reading the image" + ex);
        }
        return  imageByteArray;
    }

    public static String changeFromByteTypeToStringType(byte[] imageByte)
    {
        String imageDataString = encodeImage(imageByte);
//                .replaceAll("_","/");
        File file = new File(imageDataString);
        if(file!=null) {
            try {
                FileInputStream imageFile = new FileInputStream(file);

                imageFile.read(imageByte);


                imageByte = decodeImage(imageDataString);

                FileOutputStream imageOutFile = new FileOutputStream(SERVER_UPLOAD_LOCATION_FOLDER + "imageTest" + imageDataString.substring(50, 60) + ".jpg");
                imageOutFile.write(imageByte);
                imageFile.close();
                imageOutFile.close();
                System.out.println("Image Successfully Manipulated!");
            } catch (FileNotFoundException e) {
                System.out.println("Image Not Found" + e);
            } catch (IOException ex) {
                System.out.println("Exception while reading the image" + ex);
            }
        }
        return "data:image/jpeg;base64,"+ imageDataString;
//        "data:image/jpeg;base64,"+
    }



//    data:image\jpeg;base64,

    public static String encodeImage(byte[] imageByteArray) {
        return Base64.encodeBase64URLSafeString(imageByteArray);
    }
    /**
     * Decodes the base64 string into byte array
     *
     * @param imageDataString - a {@link java.lang.String}
     * @return byte array
     */
    public static byte[] decodeImage(String imageDataString)
    {
        return Base64.decodeBase64(imageDataString);
    }

//    public static BookEntity fromBom(Book bom)
//    {
//        if(bom==null)
//        {
//            return null;
//        }
//        BookEntity entity = new BookEntity();
//        entity.setIsbn(bom.getIsbn());
//        entity.setBookname(bom.getBookname());
//        entity.setPrice(bom.getPrice());
//        entity.setImage( bom.getImage());
//        entity.setDescription(bom.getDescription());
//        entity.setCopyright(bom.getCopyright());
//        entity.setEdition(bom.getEdition());
//        entity.setBooktype(bom.getBooktype());
//        entity.setStatus(bom.getStatus());
//        entity.setAuthors(bom.getAuthors());
//        return entity;
//    }


    public BookEntity(String isbn, String bookname, byte[] image, Float price, String description, Date copyright, Integer edition, BookType booktype, Status status, String authors, Integer ownbookid) {
        this.isbn = isbn;
        this.bookname = bookname;
        this.image = image;
        this.price = price;
        this.description = description;
        this.copyright = copyright;
        this.edition = edition;
        this.booktype = booktype;
        this.status = status;
        this.authors = authors;
        this.ownbookid = ownbookid;
    }

    public Integer getOwnbookid() {
        return ownbookid;
    }

    public void setOwnbookid(Integer ownbookid) {
        this.ownbookid = ownbookid;
    }


    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCopyright() {
        return copyright;
    }

    public void setCopyright(Date copyright) {
        this.copyright = copyright;
    }

    public Integer getEdition() {
        return edition;
    }

    public void setEdition(Integer edition) {
        this.edition = edition;
    }

    public BookType getBooktype() {
        return booktype;
    }

    public void setBooktype(BookType booktype) {
        this.booktype = booktype;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        BookEntity that = (BookEntity) o;

        if (isbn != null ? !isbn.equals(that.isbn) : that.isbn != null) return false;
        if (bookname != null ? !bookname.equals(that.bookname) : that.bookname != null) return false;
        if (image != null ? !image.equals(that.image) : that.image != null) return false;
        if (price != null ? !price.equals(that.price) : that.price != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (copyright != null ? !copyright.equals(that.copyright) : that.copyright != null) return false;
        if (edition != null ? !edition.equals(that.edition) : that.edition != null) return false;
        if (booktype != that.booktype) return false;
        return status == that.status;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (isbn != null ? isbn.hashCode() : 0);
        result = 31 * result + (bookname != null ? bookname.hashCode() : 0);
        result = 31 * result + (image != null ? image.hashCode() : 0);
        result = 31 * result + (price != null ? price.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (copyright != null ? copyright.hashCode() : 0);
        result = 31 * result + (edition != null ? edition.hashCode() : 0);
        result = 31 * result + (booktype != null ? booktype.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        return result;
    }
}
