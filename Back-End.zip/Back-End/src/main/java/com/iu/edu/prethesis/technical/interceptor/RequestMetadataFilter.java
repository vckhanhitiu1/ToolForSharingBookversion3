package com.iu.edu.prethesis.technical.interceptor;

import javax.inject.Inject;


import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Created by Vo on 2/2/2017.
 */
@Provider
@PreMatching
public class RequestMetadataFilter implements ContainerRequestFilter{

    @Inject
    RequestMetadata requestMetadata;

    @Override
    public void filter(ContainerRequestContext containerRequestContext) throws IOException {
        List<Locale> headerAcceptableLanguage = containerRequestContext.getAcceptableLanguages();

        requestMetadata.setLocale(headerAcceptableLanguage);

    }
}
