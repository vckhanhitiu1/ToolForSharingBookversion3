package com.iu.edu.prethesis.data.bom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by Vo on 1/18/2017.
 */
@XmlRootElement
@XmlSeeAlso(Book.class)
public class BookList extends ArrayList<Book>{

    public BookList() {
        super();
    }
    public BookList(Collection<? extends Book> b)
    {
        super(b);
    }

    public List<Book> getBooks()
    {
        return this;

    }
    public void setBooks(List<Book> books)
    {
        this.addAll(books);

    }
}
