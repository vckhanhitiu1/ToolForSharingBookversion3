package com.iu.edu.prethesis.data;


import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.function.Consumer;


/**
 * Created by Vo on 2/6/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SortByCriteria implements Serializable {

    private static final long serialVersionUID = 1L;
    private List<SortCriteria> order = null;

    public SortByCriteria() {
    }

    public SortByCriteria(String queryParamArg) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.findAndRegisterModules();
        SortByCriteria queryObject;
        queryObject = mapper.readValue(queryParamArg, SortByCriteria.class);
        this.order = queryObject.order;
    }

    public List<SortCriteria> getOrder() {
        return order;
    }

    public void setOrder(List<SortCriteria> order) {
        this.order = order;
    }

    public boolean isContainsField(String field) {
        for (SortCriteria sortCriteria : order) {
            if (sortCriteria.getField().equalsIgnoreCase(field))
                return true;
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder("EIOrderByCriteria - ");
        if (order != null){
            builder.append("order: ");
            order.forEach(entry -> builder.append(entry).append(";"));
        }else{
            builder.append("no order;");
        }
        return builder.toString();
    }
}
