package com.iu.edu.prethesis.technical;

import org.apache.commons.lang.RandomStringUtils;

import javax.ejb.Singleton;

/**
 * Created by Vo on 3/2/2017.
 */

@Singleton
public class EnumeratorService{

    public static final int CODE_LENGTH = 10;

    public synchronized String generateUniqueCode()
    {
        return RandomStringUtils.randomAlphanumeric(CODE_LENGTH);
    }
}
