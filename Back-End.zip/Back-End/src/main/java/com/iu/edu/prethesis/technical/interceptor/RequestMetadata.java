package com.iu.edu.prethesis.technical.interceptor;

import javax.enterprise.context.RequestScoped;
import java.util.List;
import java.util.Locale;

/**
 * Created by Vo     on 2/2/2017.
 */
@RequestScoped
public class RequestMetadata{
    private Locale locale = Locale.US;

//    public RequestMetadata(Locale locale) {
//        this.locale = locale;
//    }

    public RequestMetadata() {
    }

    public Locale getLocale()
    {
        return locale;
    }

    public void setLocale(List<Locale> headerAcceptableLanguage)
    {
        if(isSpecificLanguage(headerAcceptableLanguage))
        {
            Locale language =headerAcceptableLanguage.get(0);
            if(isVietnamese(language))
                locale= new Locale("vi","VN");
        }
    }

    private boolean isVietnamese(Locale language) {
        return "vi".equals(language.getLanguage());
    }


    private boolean isSpecificLanguage(List<Locale> headerAcceptableLanguage) {
        return !headerAcceptableLanguage.isEmpty() && (headerAcceptableLanguage.size() <= 1);

    }


}
