package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.addrbom.Address;
import com.iu.edu.prethesis.data.addrbom.GPSLocation;
import com.iu.edu.prethesis.entity.AddressEntity;
import com.iu.edu.prethesis.entity.GPSLocationEntity;

import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

@Stateless
public class AddressService extends GenericService<AddressEntity, Address> {

    public AddressService() {
        super(AddressEntity.class);

    }

    public void save(@Valid Address address)
    {
        AddressEntity previousAddressEntity = this.findByMemberId(address.getMemberId());
        AddressEntity currentAddressEntity = this.toEntity(address);
        if(previousAddressEntity != null && previousAddressEntity.getMemberId().equals(currentAddressEntity.getMemberId()) )
        {
            this.save(previousAddressEntity);
            address.setId(previousAddressEntity.getId());
        }
        this.save(currentAddressEntity);
        address.setId(currentAddressEntity.getId());
    }
    public boolean isSame(AddressEntity previousAddressEntity, AddressEntity currentAddressEntity) {
        return Objects.equals(previousAddressEntity.getMemberId(), currentAddressEntity.getMemberId()) &&
                Objects.equals(previousAddressEntity.getCountry(), currentAddressEntity.getCountry()) &&
                Objects.equals(previousAddressEntity.getProvince(), currentAddressEntity.getProvince()) &&
                Objects.equals(previousAddressEntity.getDistrict(), currentAddressEntity.getDistrict()) &&
                Objects.equals(previousAddressEntity.getWard(), currentAddressEntity.getWard()) &&
                Objects.equals(previousAddressEntity.getStreet(), currentAddressEntity.getStreet()) &&
                Objects.equals(previousAddressEntity.getHouseNr(), currentAddressEntity.getHouseNr());
    }


    public AddressEntity findByMemberId(Integer memberId) {
        TypedQuery<AddressEntity> query = em.createNamedQuery(AddressEntity.FIND_BY_MEMBER_ID, AddressEntity.class);
        query.setParameter("memberId", memberId);
        List<AddressEntity> results = query.getResultList();
        if(results.isEmpty())
            return null;
        return results.get(0);
    }

   @Override
    public AddressEntity toEntity(Address bom) {
        if (bom == null) {
            return null;
        }
        AddressEntity entity = new AddressEntity();
        entity.setId(bom.getId());
        entity.setMemberId(bom.getMemberId());
        entity.setCountry(bom.getCountry());
        entity.setDistrict(bom.getDistrict());
        entity.setHouseNr(bom.getHouseNr());
        entity.setProvince(bom.getProvince());
        entity.setStreet(bom.getStreet());
        entity.setWard(bom.getWard());
        entity.setGpsLocation(GPSLocationEntity.fromBom(bom.getGpslocation()));
        return entity;
    }

    @Override
    public Address toBom(AddressEntity entity) {
        if (entity == null) {
            return null;
        }
        Address bom = new Address();
        bom.setId(entity.getId());
        bom.setMemberId(entity.getMemberId());
        bom.setCountry(entity.getCountry());
        bom.setDistrict(entity.getDistrict());
        bom.setHouseNr(entity.getHouseNr());
        bom.setProvince(entity.getProvince());
        bom.setStreet(entity.getStreet());
        bom.setWard(entity.getWard());
        bom.setGpslocation(GPSLocation.fromEntity(entity.getGpsLocation()));
        return bom;
    }

}
