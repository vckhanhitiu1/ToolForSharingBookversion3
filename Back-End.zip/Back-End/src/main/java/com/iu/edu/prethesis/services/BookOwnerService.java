package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.BookOwner;
import com.iu.edu.prethesis.data.bom.Member;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.BookOwnerEntity;
import com.iu.edu.prethesis.entity.MemberEntity;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.TypedQuery;
import javax.validation.Valid;
import java.util.List;

/**
 * Created by Vo on 6/7/2017.
 */
@Stateless
public class BookOwnerService extends GenericService<BookOwnerEntity,BookOwner> {


    @EJB
    MemberService memberService;

    @EJB
    MemberFacade memberFacade;

    @EJB
    BookFacade bookFacade;

    @EJB
    BookService bookService;


    public BookOwnerService() {
        super(BookOwnerEntity.class);
    }

    public void save(@Valid BookOwner bookOwner) throws Exception {
        validateBookInfoInDatabase(bookOwner);
//        validateBookInfo(bookOwner);
        this.saveData(bookOwner);
    }

    public void saveData(@Valid BookOwner bookOwner)
    {
        BookOwnerEntity currentbookOwnerEntity = this.toEntity(bookOwner);

        List<BookOwnerEntity> previousBookOwnerEntityOfBookOwnerEntityList =
                this.findListByBookIsbn(bookOwner.getIsbn());

        if(previousBookOwnerEntityOfBookOwnerEntityList!=null) {
            for(BookOwnerEntity bookOwnerEntity:previousBookOwnerEntityOfBookOwnerEntityList){
            if (bookOwnerEntity.getIsbn().equals(currentbookOwnerEntity.getIsbn())) {
                MemberEntity memberEntity = memberService.findByCode(bookOwnerEntity.getMembercode());

                Member member = memberService.toBom(memberEntity);
                if (member != null) {
                    bookOwner.getMemberList().add(member);
                    memberFacade.save(member);
                    member.setId(memberEntity.getId());
                }
            }

            }
        }
        this.save(currentbookOwnerEntity);
        bookOwner.setId(currentbookOwnerEntity.getId());

        List<Member> members = bookOwner.getMemberList();
        if(members!=null)
        {
            for(Member member:members)
            {
                memberFacade.save(member);
            }
        }

    }

    private void validateBookInfo(BookOwner bookOwner) throws Exception {
        String isbn = bookOwner.getIsbn();
        bookFacade.readBookByISBN(isbn);
    }
    private void validateBookInfoInDatabase(BookOwner bookOwner) throws Exception {
        String isbn = bookOwner.getIsbn();
        BookEntity bookEntity = bookService.findByIsbn(isbn);
        if(bookEntity==null)
        {
            throw  new Exception("Book does not exist");
        }

    }

    public List<BookOwnerEntity> findAll() {
        TypedQuery<BookOwnerEntity> query = em.createNamedQuery(BookOwnerEntity.FIND_ALL, BookOwnerEntity.class);
        return query.getResultList();
    }

    public BookOwnerEntity findByBookIsbn(String isbn)
    {
        TypedQuery<BookOwnerEntity> query = em.createNamedQuery(BookOwnerEntity.FIND_BY_BOOK_ISBN, BookOwnerEntity.class);
        query.setParameter("isbn",isbn);
        List<BookOwnerEntity> results = query.getResultList();
        if(results.isEmpty())
            return null;
        return  results.get(0);
    }


    public List<BookOwnerEntity> findListByBookIsbn(String isbn)
    {
        TypedQuery<BookOwnerEntity> query = em.createNamedQuery(BookOwnerEntity.FIND_BY_BOOK_ISBN, BookOwnerEntity.class);
        query.setParameter("isbn",isbn);
        List<BookOwnerEntity> results = query.getResultList();
        if(results.isEmpty())
            return null;
        return  results;
    }


    @Override
    public BookOwnerEntity toEntity(BookOwner bom) {
        if(bom==null) {
            return null;
        }
        BookOwnerEntity entity = new BookOwnerEntity();
        entity.setIsbn(bom.getIsbn());
        entity.setBookname(bom.getBookname());
            for (Member member : bom.getMemberList()) {
                entity.setMembercode(member.getAccountCode());
                entity.setMembername(member.getName());
            }

       return entity;
    }

    @Override
    public BookOwner toBom(BookOwnerEntity entity) {
        if(entity==null)
        {
            return null;
        }
        BookOwner bom = new BookOwner();
        bom.setBookname(entity.getBookname());
        bom.setIsbn(entity.getIsbn());
        return bom;

    }
}
