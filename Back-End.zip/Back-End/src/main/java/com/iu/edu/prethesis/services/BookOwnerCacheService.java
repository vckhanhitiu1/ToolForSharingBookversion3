package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.BookOwnerSearchField;
import com.iu.edu.prethesis.data.SearchCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.BookOwner;
import com.iu.edu.prethesis.data.bom.Member;
import com.iu.edu.prethesis.technical.BookOwnerComparator;
import com.iu.edu.prethesis.technical.ComparisonExpressionEvaluator;
import com.iu.edu.prethesis.technical.cache.CacheProviderContainer;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

/**
 * Created by khanhvo on 6/18/17.
 */
@Stateless
public class BookOwnerCacheService extends  GenericCacheService<String,BookOwner> implements Serializable
{


    @EJB
    CacheProviderContainer cacheProviderContainer;

    @PostConstruct
    public void initCache()
    {
        setCache(cacheProviderContainer.<String,BookOwner>getCache(BookOwner.class));
    }


    @Override
    protected void sort(List<BookOwner> list, SortByCriteria orderBy) {
        Collections.sort(list, new BookOwnerComparator(orderBy));
    }

    @Override
    public Predicate<BookOwner> createSingleSearchCondition(SearchCriteria criteria)
    {
        if(BookOwnerSearchField.BOOK_NAME.getLiteral().equalsIgnoreCase(criteria.getField()))
        {
            return new Predicate<BookOwner>(){
                @Override
                public boolean test(BookOwner s) {
                    return ComparisonExpressionEvaluator.evaluate(s.getBookname(), criteria.getExpression(), criteria.getValue().toString());
                }
            };
        }
        if(BookOwnerSearchField.ISBN.getLiteral().equalsIgnoreCase(criteria.getField()))
        {
            return new Predicate<BookOwner>(){
                @Override
                public boolean test(BookOwner s) {
                    return ComparisonExpressionEvaluator.evaluate(s.getIsbn(), criteria.getExpression(), criteria.getValue().toString());
                }
            };
        }

        throw  new UnsupportedOperationException();
    }
}
