package com.iu.edu.prethesis.data;

/**
 * Created by Vo on 2/3/2017.
 */
public enum BookSearchField
{
    NAME("name"),

    ISBN("isbn"),

    TYPE("type"),

    STATUS("status");

    private String literal;

    BookSearchField(String literal) {
        this.literal = literal;
    }

    public String getLiteral() {
        return literal;
    }

    public void setLiteral(String literal) {
        this.literal = literal;
    }
}


