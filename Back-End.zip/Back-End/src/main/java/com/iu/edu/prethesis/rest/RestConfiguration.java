package com.iu.edu.prethesis.rest;


import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Created by Vo on 12/31/2016.
 */
@ApplicationPath("api")
public class RestConfiguration extends Application
{

}

