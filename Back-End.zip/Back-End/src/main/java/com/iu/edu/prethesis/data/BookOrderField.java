package com.iu.edu.prethesis.data;
/**
 * Created by Vo on 2/10/2017.
 */
public enum BookOrderField {

    TYPE("type"),
    NAME("name"),
    STATUS("status"),
    ISBN("isbn");

    private String literal;

    public String getLiteral() {
        return literal;
    }


    public void setLiteral(String literal) {
        this.literal = literal;
    }

    BookOrderField(String literal) {
        this.literal = literal;
    }

    @Override
    public String toString() {
        return "BookOrderField{" +
                "literal='" + literal + '\'' +
                '}';
    }
}
