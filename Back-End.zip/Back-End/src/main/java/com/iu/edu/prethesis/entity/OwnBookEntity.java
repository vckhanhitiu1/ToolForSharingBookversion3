package com.iu.edu.prethesis.entity;

import com.iu.edu.prethesis.data.bom.OwnBooks;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by Vo on 5/7/2017.
 */
@Entity
@Table(name = "own_book")
@NamedQueries({
        @NamedQuery(name=OwnBookEntity.FIND_BY_MEMBER_ID, query = "SELECT m FROM  OwnBookEntity m WHERE m.memberId = :memberId "),

//        @NamedQuery(name = OwnBookEntity.FIND_BY_BOOK_ID, query = "SELECT b FROM OwnBookEntity b WHERE b.bookId = :bookId")

})
public class OwnBookEntity extends GenericEntity implements Serializable {


    private static final String PREFIX = "com.iu.edu.prethesis.entity.OwnBookEntity";

    public static final String FIND_BY_MEMBER_ID = PREFIX + ".findByMemberId";

//    public static final String FIND_BY_BOOK_ID = PREFIX + ".findByBookId";

//
//    @Column(name = "book_id" , nullable = false)
//    private Integer bookId;
//
//    @Column(name = "book_name")
//    private String BookName;
//
//    @Column (name = "isbn" )
//    private String Isbn;

    @Column(name = "member_id", nullable = false)
    private Integer memberId;

    public OwnBookEntity(Integer memberId) {
        this.memberId = memberId;
    }

    public OwnBookEntity() {

    }


    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }


    @Override
    public String toString() {
        return "OwnBookEntity{" +
                "memberId=" + memberId +
                '}';
    }
}
