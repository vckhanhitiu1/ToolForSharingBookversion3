package com.iu.edu.prethesis.services;

import com.iu.edu.prethesis.data.RangeCriteria;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.BookOwner;
import com.iu.edu.prethesis.entity.BookOwnerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.function.Consumer;

/**
 * Created by khanhvo on 6/18/17.
 */
@Stateless
public class BookOwnerFacade {

    @EJB
    BookOwnerService bookOwnerService;

    @EJB
    BookOwnerCacheService bookOwnerCacheService;

    private static final Logger logger = LoggerFactory.getLogger(BookOwnerFacade.class);

    public void save(BookOwner bookOwner) throws Exception {
        bookOwnerService.save(bookOwner);
        bookOwnerCacheService.put(bookOwner.getIsbn(),bookOwner);

    }


    public BookOwner readByIsbn(String isbn)
    {
        BookOwner bookOwner = this.bookOwnerCacheService.get(isbn);
        if(bookOwner==null)
        {
            throw new EntityNotFoundException("The Book does not exist");
        }
        return bookOwner;
    }


    public List<BookOwner> search (SearchByCriteria searchBy, SortByCriteria orderBy , RangeCriteria range)
    {
        if(this.bookOwnerCacheService.values().isEmpty())
        {
            InitDataIntoCache();
        }
        return this.bookOwnerCacheService.search(searchBy,orderBy,range);
    }

    public void InitDataIntoCache() {

        List<BookOwnerEntity> entities = this.bookOwnerService.findAll();
        this.bookOwnerCacheService.clearAll();
        entities.forEach(new Consumer<BookOwnerEntity>(){
            @Override
            public void accept(BookOwnerEntity entity) {
                BookOwnerFacade.this.bookOwnerCacheService.put(entity.getIsbn(), bookOwnerService.toBom(entity));
            }
        });
        logger.info("+++initialize cache successfully!!!+++");
        logger.info("+++there're " + entities.size()+ " item(s) initialized in cache+++");
    }



}
