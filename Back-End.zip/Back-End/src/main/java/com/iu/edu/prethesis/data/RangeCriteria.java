package com.iu.edu.prethesis.data;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

/**
 * Created by Vo on 2/10/2017.
 */
public class RangeCriteria {

    /**
     *
     */
    private static final long serialVersionUID = 5353048820696726108L;

    private Integer from;
    private Integer to;

    public RangeCriteria() {
    }

    /**
     * @param from
     * @param to
     */
    public RangeCriteria(Integer from, Integer to) {
        this.from = from;
        this.to = to;
    }


    /**
     * @return the from
     */
    public Integer getFrom() {
        return from;
    }

    /**
     * @param from the from to set
     */
    public void setFrom(Integer from) {
        this.from = from;
    }

    /**
     * @return the to
     */
    public Integer getTo() {
        return to;
    }

    /**
     * @param to the to to set
     */
    public void setTo(Integer to) {
        this.to = to;
    }

    public static RangeCriteria fromString(String json) throws IOException {
        if (json == null) {
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, RangeCriteria.class);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RangeCriteria [from=" + from + ", to=" + to + "]";
    }


}

