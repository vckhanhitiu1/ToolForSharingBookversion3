package com.iu.edu.prethesis.data.ocr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by Vo on 5/28/2017.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class OCRRequestJSONBody {
    private String url;

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }
}
