package com.iu.edu.prethesis.data.authbom.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class LoginResponse implements Serializable {

    private String username;
    private String role;
    private String jwt;

    public LoginResponse( String username, String role, String jwt ) {
        this.username = username;
        this.role = role;
        this.jwt = jwt;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    public String getJwt() {
        return jwt;
    }
}
