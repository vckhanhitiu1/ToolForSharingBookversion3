package com.iu.edu.prethesis.rest;

import com.iu.edu.prethesis.data.RangeCriteria;
import com.iu.edu.prethesis.data.SearchByCriteria;
import com.iu.edu.prethesis.data.SortByCriteria;
import com.iu.edu.prethesis.data.bom.Book;
import com.iu.edu.prethesis.data.bom.BookOwner;
import com.iu.edu.prethesis.entity.BookEntity;
import com.iu.edu.prethesis.entity.BookOwnerEntity;
import com.iu.edu.prethesis.services.BookFacade;
import com.iu.edu.prethesis.services.BookOwnerFacade;
import com.iu.edu.prethesis.services.BookOwnerService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.net.URI;
import java.util.List;

/**
 * Created by Vo on 6/8/2017.
 */
@Stateless
@Path(value = "/bookowners")
public class BookOwnerResource {

    @Context
    private UriInfo uriInfo;

    @PersistenceContext(name = "thesisprojectPU")
    private EntityManager em;

    @EJB
    BookOwnerService bookOwnerService;

    @EJB
    BookOwnerFacade bookOwnerFacade;

    @POST
    @Consumes(value = MediaType.APPLICATION_JSON)
    @Produces(value = MediaType.APPLICATION_JSON)
    public Response creatBook(@Valid BookOwner bookOwner) throws Exception {
        bookOwnerFacade.save(bookOwner);
        URI bookUri =uriInfo.getAbsolutePathBuilder().path(bookOwner.getId().toString()).build();
        return Response.created(bookUri).build();
    }

    @GET
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public List <BookOwner> search(@QueryParam("searchBy") SearchByCriteria searchByCriteria,
                              @QueryParam("sortBy") SortByCriteria sortByCriteria,
                              @QueryParam("range") RangeCriteria rangeCriteria
    ) {
        return bookOwnerFacade.search(searchByCriteria, sortByCriteria, rangeCriteria);
    }
    @Path("search")
    @GET
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_JSON})
    public List<BookOwnerEntity> getAll()
    {
        return bookOwnerService.findAll();
    }

    @GET
    @Path("findisbn/{isbn}")
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_JSON})
    public BookOwnerEntity getByISBN(@PathParam("isbn") String isbn){

    BookOwnerEntity bookOwnerEntity = bookOwnerService.findByBookIsbn(isbn);
     if(bookOwnerEntity!=null)
     {
         return bookOwnerEntity ;
     }
         throw new NotFoundException("Book does not exist");
    }

    @GET
    @Path("{isbncache}")
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_JSON})
    public BookOwner getCacheISBN(@PathParam("isbncache") String isbn)
    {
        BookOwner bookOwner = bookOwnerFacade.readByIsbn(isbn);
        if(bookOwner== null)
        {
            throw new NotFoundException("Book does not exist");
        }
        return bookOwner;
    }


}
