export const AUTO_COMPLETE_INPUT = 'auto-complete-input';

export const GPS_INPUT = 'gps-input';

export const GPS_LAT_INPUT = 'gps-latitude-input';

export const GPS_LNG_INPUT = 'gps-longitude-input';

