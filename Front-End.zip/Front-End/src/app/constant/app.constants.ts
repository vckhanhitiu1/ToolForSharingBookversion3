export const GOOGLE_MAP = {
    // API_KEY: registered at console.developers.google.com in order to use Google Maps API
    API_KEY: 'AIzaSyACGaDxyjAqy8uZMSq7uGGqPcinO_Z0IsU',
    // Default location on map when user location can not be retrieved
    HCM_LOCATION: {
        latitude: 10.762622,
        longitude: 106.660172
    },
    DEFAULT_ZOOM_LEVEL: 15,
    //Customized Marker Icon

};

export const APP_OPTIONS = {

  mapDisplayOption:{
    showAllMember: false,
    memberEditMode: false
  },
  ownBookDataDisplayOption: {
    ownBookToolbarDisplayOption: {

      hideEditButton: false,
      hideSwitchModeButton: false,
      expandMode: false
    }
  }

};
