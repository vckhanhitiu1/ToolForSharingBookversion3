import {Component} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {MapComponent} from './components/map.component';
import {OcrComponent} from './components/ocr.component';
import {HomeComponent} from './components/home.component';
import {BookRegistrationComponent} from './components/bookregistration.component';
import {MemberRegitrationFormComponent} from './components/memberregistration.component';
import {NotFoundComponent} from './components/notfound.component';
import {LoginComponent} from './components/login/login.component';
import {RegisterComponent} from './components/register/register.component';
import {AuthGuard} from './services/auth.guard.service'
import {SearchBookOnMapComponent} from "./components/searchbook_onmap.component";
import {BookComponent} from "./components/book.component";
import {MemberComponent} from "./components/member.component";
import {MemberDetailComponent} from "./components/member_detail.component";
import {GetOcrComponent} from "./components/getocr.component";
import {AdminComponent} from "./components/admin/admin.component";
import {MemberHomePageComponent} from "./components/memberPage/member_hompage.component";
@Component({
  selector: 'fountain-root'
})
export class RootComponent {}

export const routes: Routes = [

  {
    path: '',
    component: HomeComponent
  },
  {
  path:'login',
  component: LoginComponent
},
{
  path:'register',
  component:RegisterComponent
},
  {
    path:'searchbookonmap',
    component:SearchBookOnMapComponent
  },
  {
    path:'admin',
    component:AdminComponent,
    canLoad:[AuthGuard]
  },
// {
//   path:'map',
//   component:MapComponent
// },
{
  path:'bookregistration',
  component: BookRegistrationComponent,
  canLoad: [AuthGuard]

},
{
  path: 'memberregistration',
  component:MemberRegitrationFormComponent,

},
  {
    path:'bookdetail',
    component:BookComponent
  },
  {
    path:'member-detail/:accountCode',
    component:MemberDetailComponent
  },
  {
    path:'memberdetail',
    component:MemberComponent
  },
  {
    path:'member-list/:accountCode',
    component:MemberComponent
  },
  {
    path:'book-list/:accountCode',
    component:BookComponent
  },
  {
    path:'get-ocr',
    component:GetOcrComponent

  },
  {
    path:'memberhomepage/:email',
    component:MemberHomePageComponent,
    canLoad:[AuthGuard]
  },

  {
    path:'ocr',
    component:OcrComponent
  },


  {
  path: '**',
  component: NotFoundComponent
}
];

export const routing = RouterModule.forRoot(routes);
