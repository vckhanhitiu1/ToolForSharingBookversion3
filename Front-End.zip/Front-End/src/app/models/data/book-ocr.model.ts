import {BookType} from "./BookType.model";
import {BookStatus} from "./BookStatus.model";
/**
 * Created by khanhvo on 7/1/17.
 */
export class BookOCR {
  id?: number;
  isbn?: string;
  bookname?: string;
  price?: number;
  description?: string;
  copyright?: Date;
  edition?: number;
  booktype?: BookType;
  bookstatus?: BookStatus;
  authors?: string;
  image?: string;


  constructor(that: BookOCR) {
    this.id = that.id;
    this.isbn = that.isbn;
    this.bookname = that.bookname;
    this.price = that.price;
    this.description = that.description;
    this.copyright = that.copyright;
    this.edition = that.edition;
    this.booktype = that.booktype;
    this.bookstatus = that.bookstatus;
    this.authors = that.authors;
    this.image = that.image;
  }
}
