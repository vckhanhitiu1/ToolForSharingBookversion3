
import {GPSLocation} from "./GPSLocation.model";

export interface AddressInterface {
    id?: number;
    country?: string;
    province?: string;
    district?: string;
    ward?: string;
    street?: string;
    houseNr?: string;
    gpslocation?: GPSLocation;
}

export class Address implements AddressInterface {
  id?: number;
  country?: string;
  province?: string;
  district?: string;
  ward?: string;
  street?: string;
  houseNr?: string;
  gpslocation?: GPSLocation;


    constructor(that: AddressInterface) {
        if (that !== null) {
            this.id = that.id;

            this.country = that.country;
            this.province = that.province;
            this.district = that.district;
            this.ward = that.ward;
            this.street = that.street;
            this.houseNr = that.houseNr;
            if (that.gpslocation !== null)
                this.gpslocation = new GPSLocation(that.gpslocation.latitude, that.gpslocation.longtitude);

        }
    }

    public toString(): string {
        return this.appendStringWithSymbol(this.houseNr, ' ') +
            this.appendStringWithComma(this.street) +
            this.appendStringWithComma(this.ward) +
            this.appendStringWithComma(this.district) +
            this.appendStringWithComma(this.province) +
            this.appendStringWithSymbol(this.country, '.');
    };

  private appendStringWithComma(stringToAppend: string): string {
    return this.appendStringWithSymbol(stringToAppend, ', ');
  };

  private appendStringWithSymbol(stringToAppend: string, symbol: string): string {
    if (stringToAppend == null || stringToAppend.length <= 0)
      return '';
    return `${stringToAppend}${symbol}`;
  };

  public isValid(): boolean {
        return this.countryValidation() &&
                this.provinceValidation() &&
                this.districtValidation() &&
                this.wardValidation() &&
                this.streetValidation() &&
                this.houseNrValidation() &&
                this.gpsLocationValidation();
    }

    private countryValidation(): boolean {
        return (this.country !== null) && (this.country.length <= 50) && (this.country.length >= 1);
    }

    private provinceValidation(): boolean {
        return (this.province !== null) && (this.province.length <= 50) && (this.province.length >= 1);
    }

    private districtValidation(): boolean {
        return (this.district === null) || (this.district.length <= 50);
    }

    private wardValidation(): boolean {
        return (this.ward === null) || (this.ward.length <= 50);
    }

    private streetValidation(): boolean {
        return (this.street === null) || (this.street.length <= 50);
    }

    private houseNrValidation() {
        return (this.houseNr === null) || (this.houseNr.length <= 50);
    }

    private gpsLocationValidation(): boolean {
        return this.gpslocation !== null;
    }

    public equals(other: Address):boolean {
        if (this === null && other === null) return true;
        if (this === null && other !== null) return false;
        if (this !== null && other === null) return false;
        if (this.gpslocation !== null) {
            return this.houseNr === other.houseNr &&
                this.street === other.street &&
                this.ward === other.ward &&
                this.district === other.district &&
                this.province === other.province &&
                this.country === other.country &&
                this.gpslocation.latitude === other.gpslocation.latitude &&
                this.gpslocation.longtitude == other.gpslocation.longtitude;
        } else {
            if (other.gpslocation === null)
                return this.houseNr === other.houseNr &&
                    this.street === other.street &&
                    this.ward === other.ward &&
                    this.district === other.district &&
                    this.province === other.province &&
                    this.country === other.country;
            else
                return false;
        }
    }
}
