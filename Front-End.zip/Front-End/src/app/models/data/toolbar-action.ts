export interface Action {
    type: TOOLBAR_ACTION_TYPE;
    payload?: any;
}

export enum TOOLBAR_ACTION_TYPE {
    DOWNLOAD,
    SHARE,
    EXPAND,
    COLLAPSE,
    EDIT,
    CANCEL_EDIT,
    SAVE_SUCCESS
}