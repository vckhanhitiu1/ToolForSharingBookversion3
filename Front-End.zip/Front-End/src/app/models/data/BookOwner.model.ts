import {Member} from "./Member.model";
/**
 * Created by khanhvo on 6/18/17.
 */

export class BookOwner
{
  id: number;
  isbn: string;
  bookname:string;
  memberList: Member[];
}
