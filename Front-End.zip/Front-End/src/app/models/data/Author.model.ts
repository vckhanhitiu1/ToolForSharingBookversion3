export interface AuthorsInterface{
	firstname?: string;
	lastname?: string;
	bookId ?: number;
}

export class Authors implements AuthorsInterface
{
	firstname:string;
	lastname: string;
	bookId : number;

	constructor(that:AuthorsInterface)
	{
		if(that!=null){
		this.firstname = that.firstname;
		this.lastname=that.lastname;
		this.bookId = that.bookId;
	}
	}
}