
export class GPSLocation {
    latitude?: number;
    longtitude?: number;

    constructor(lat: number, lng: number) {
        this.latitude = lat;
        this.longtitude = lng;
    }

    toString() {
        return "latitude: " + this.latitude + " longitude: " + this.longtitude;
    }

    equals(other: GPSLocation): boolean {
      return (this.latitude === other.latitude) && (this.longtitude === other.longtitude);
    }
}
