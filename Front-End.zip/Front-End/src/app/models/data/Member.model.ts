/**
 * Created by Vo on 2/16/2017.
 */
import {Address} from "./Address.model";
import {OwnBooks} from "./ownbook.model";
export interface MemberInterface{

   id?:number;
  emailAddress?:string;
  image?:string;
  name?:string;
  phoneNr?:string;
  accountCode?:string;
  address?: Address;
  ownBooks?: OwnBooks;
 
}
export class Member implements MemberInterface
{
  id?:number;
  emailAddress?:string;
  image?:string;
  name?:string;
  phoneNr?:string;
  accountCode?:string;
  address?:Address;
  ownBooks?: OwnBooks;
  


  constructor(that:MemberInterface) {
    if(that!=null){
    this.id = that.id;
    this.emailAddress = that.emailAddress;
    this.image = that.image;
    this.name = that.name;
    this.phoneNr = that.phoneNr;
    this.accountCode= that.accountCode;
   if(that.address!=null){
   this.address = new Address(that.address);
   }
   if(that.ownBooks!=null)
   { 
     this.ownBooks= new OwnBooks(that.ownBooks)
   }
  
    }
  }
  public compareNameAndAddress(other:Member):boolean
  {
    console.log('this member: ', this);
    console.log('other member: ', other);
    if (this === null && other === null) return true;
    if (this !== null && other === null) return false;
    if (this === null && other !== null) return false;
    return this.name === other.name
    && this.address.equals(other.address);

  }
}
