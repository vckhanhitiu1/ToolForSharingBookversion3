import {Book} from "./Book.model";


export interface OwnBooksInterface
{
	id?: number;
	books?: Book[];
	memberId?: number;
}

export class OwnBooks implements OwnBooksInterface
{
	id?: number;
	books?: Book[];
	memberId?: number;

	constructor(that : OwnBooksInterface)
	{
		if(that!=null)
		{
		this.id = that.id;
		if(that.books!=null)
		{
			that.books= this.books;
		}
		this.memberId= that.memberId;
	}
	}
}