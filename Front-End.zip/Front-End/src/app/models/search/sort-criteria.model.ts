export default class SortCriteria {
    field: string;
    descending: boolean;

    constructor(field: string, descending: boolean) {
        this.field = field;
        this.descending = descending;
    }
}