import {ComparisonExpression} from "./comparison-expression.model";
export  class SearchCriteria {

    field: string;

    expression: ComparisonExpression;

    value: string | number;

    constructor(searchCriteria: {
        field: string
        expression: ComparisonExpression,
        value: string | number}) {
        this.expression = searchCriteria.expression;
        this.value = searchCriteria.value;
        this.field = searchCriteria.field;
    }
}
