/**
 * Created by khanhvo on 6/30/17.
 */
export enum BookSearchField
{
  NAME,
  ISBN,
  TYPE,
  STATUS
}

export enum MemberSearchField
{
  NAME,
  LOCATION,
  EMAIL,
  CODE
}
