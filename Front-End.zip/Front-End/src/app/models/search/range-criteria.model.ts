export default class RangeCriteria {

    constructor(public from?: number, public to?: number) {
        this.from = from;
        this.to = to;
    }


}