import SortCriteria from "./sort-criteria.model";

export default class SortByCriteria {
    order: Array<SortCriteria>;


    constructor(order: Array<SortCriteria>) {
        this.order = order;
    }
}