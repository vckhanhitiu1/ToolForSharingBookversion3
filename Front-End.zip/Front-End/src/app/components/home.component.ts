/**
 * Created by Vo on 2/22/2017.
 */
import {Component, ViewChild, Output, EventEmitter, Input, OnInit} from "@angular/core";
import {Book} from "../models/data/Book.model";
import {BookService} from "../services/book.service";

@Component({
  selector: 'home',
  template:`
    <div class="container">
      <h1>WelCome to Book Library</h1>
      <section id="products">
        <div class="row">
          <div class="container">
            <h2>{{favoriteMessage}}</h2>
          </div>
          <div class="col-md-4"
               *ngFor="let book of books">
            <div class="thumbnail">
              <img src="data:image/jpeg;base64,{{book.image}}">
                   <!--[style.width.px]="imageWidth"-->
                   <!--*ngIf="showImage"-->
              <!--/>-->
              <div class="caption">
                <h4 class="pull-right">
                  {{book.price | currency:'USD':true}}
                </h4>
                
                <h4>{{book.bookname}}</h4>
                <p><b>ISBN: </b>{{book.isbn}}</p>
                <p><b>Authors: </b>{{book.authors}}</p>
                <p><b>Description: </b>{{book.description}}</p>
                <p><b>CopyRight: </b>{{book.copyright | date: 'longDate'}}</p>
                <p><b>Edidtion: </b>{{book.edition}}</p>
                <p><b>Book Type: </b>{{book.booktype}}</p>
                <p><b>Book Status: </b>{{book.bookstatus}}</p>
                <bs-favorite
                  [favorite]="book.bookname"
                  (favoriteClicked)="onFavoriteClicked($event)">
                </bs-favorite>
                
              </div>
            </div>
            
          </div>
        </div>
      </section>
    </div>
  `

})
export class HomeComponent implements OnInit
{
  private books:Book[];
  favoriteMessage:string='';
  errorMessage:string;

  constructor(private bookservice:BookService){
  }

  ngOnInit()
  {
    this.bookservice.GetListBook().subscribe(
      (book:Book[])=>{this.books=book
      },
      error=> this.errorMessage = <any>error
    );
  }

  onFavoriteClicked(message: string): void {
    this.favoriteMessage = message;
  }


}
