/**
 * Created by khanhvo on 6/19/17.
 */
import {Component, OnInit} from "@angular/core";
import {SearchBookOnMapService} from "../services/searchbook_onmap.service";
@Component({
  selector:`bookowner-registration`,
  template:`
    <form #bookownerform ="ngForm" (ngSubmit)="SaveForm()">
      <div class="form-group">
        <label>Book ISBN</label>
        <input type="text" class="form-control" name="isbn" required #isbn [(ngModel)]="bookowner.isbn"/>
      </div>
      <div class="form-group">
        <label>Book Name</label>
        <input type="text" class="form-control" name="bookname" required #bookname [(ngModel)]="bookowner.bookname"/>
      </div>
      <div class="form-group">
        <label>Book ISBN</label>
        <input type="text" class="form-control" name="isbn" required #isbn [(ngModel)]="bookowner.isbn"/>
      </div>
      <div class="form-group">
        <label>Book ISBN</label>
        <input type="text" class="form-control" name="isbn" required #isbn [(ngModel)]="bookowner.isbn"/>
      </div>
      
    </form>
  `
})
export class BookOwnerRegistrationComponent implements OnInit
{

  public bookowner:any;

  constructor(private searchbookonmapservice:SearchBookOnMapService){
}
ngOnInit()
{
  this.bookowner={};
}

SaveForm()
{
  this.searchbookonmapservice.PostBookOwner(this.bookowner)
    .subscribe(response =>{
      if(response)
      {
        alert('Add Sucess');
      }
      else {
        alert('wrong info')
      }
    });
}

}
