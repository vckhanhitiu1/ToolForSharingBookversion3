/**
 * Created by Vo on 2/16/2017.
 */
import {Component, OnInit} from '@angular/core';
import {AppOptions, ResourceService} from "../services/resources.service";
import {Member} from "../models/data/Member.model";
import {Observable} from "rxjs/Observable";
import {MemberService} from "../services/member.service";
import {LogInService} from '../services/login.service';
import {Action, TOOLBAR_ACTION_TYPE} from "../models/data/toolbar-action";


@Component({
  selector:'app-root',
  template:
  `
  <div>
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">BookSharing</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a routerLink="/" routerLinkActive="active" >Home</a></li>
            <!--<li><a routerLink="/map" routerLinkActive="active">View On Map</a></li>-->
            <li><a routerLink="/bookregistration" routerLinkActive="active">Add New Book</a></li>
            <li><a routerLink="/memberregistration" routerLinkActive="active">Add New Member</a></li>
            <li><a routerLink="/searchbookonmap" routerLinkActive="active">Search Book On Map</a></li>
            <li><a routerLink="/bookdetail" routerLinkActive="active">Show Book Details</a></li>
            <li><a routerLink="/memberdetail" routerLinkActive="active">Show Member Detail</a></li>
            <li><a routerLink="/ocr" routerLinkActive="active">Create New Book With OCR</a></li>
            <li><a routerLink="/get-ocr" routerLinkActive="active">Get Book By OCR</a></li>
            <li> <a routerLink="/admin" routerLinkActive="active">Admin</a></li>
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a routerLink="/login" routerLinkActive="active" >Log In</a></li>
            
          </ul>
          
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    <generate-map
    [members]="members | async "
    [ownBookDataDisplayOption]="appOptions.ownBookDataDisplayOption"
    [ownBookDisplayOption]= "appOptions.mapDisplayOption"
    (onActionDispatch)="handleAction($event)">
    </generate-map>

    <div class="container">
      <router-outlet></router-outlet>
    </div><!-- /.container -->

    

    <hr>
    <footer>
      <div class="row">
        <div class="col-lg-12">
          <p>© Copyright 2017. KHANH VO AAVN. All Rights Reserved. </p>
        </div>
      </div>
    </footer>
  </div>
    
  `,
  providers:[MemberService, LogInService]

})
export class AppComponent {

   public isLoggedin: boolean;

  private members: Observable<Member[]>;
  private appOptions: AppOptions;

  constructor(private resourceService: ResourceService, private memberService: MemberService, private loginservice:LogInService)
  {
    this.appOptions= this.resourceService.getAppOption();
    // this.members = this.memberService.getMemberWithDisplayMode(this.appOptions.mapDisplayOption.showAllMember);
     this.members = this.memberService.GetListMember();
  }
  //  ngOnInit() {
  //   this.isLoggedin = this.loginservice.IsLogged();
  // }
  // Logout() {
  //   this.loginservice.SetLogin(false);
  //   alert('Logged out');
  // }


  private handleAction(action:Action)

  {
    switch (action.type)
    {
      case TOOLBAR_ACTION_TYPE.EDIT:
        this.appOptions.mapDisplayOption.memberEditMode= true;
        break;
      case TOOLBAR_ACTION_TYPE.CANCEL_EDIT:
        this.appOptions.mapDisplayOption.memberEditMode=false;
      default:
        break;
    }
  }
}
