/**
 * Created by khanhvo on 6/22/17.
 */
import {Component, OnDestroy, OnInit} from "@angular/core";
import {MemberService} from "../services/member.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Subscription} from "rxjs/Subscription";
import {Member} from "../models/data/Member.model";
@Component({
  selector:'member-detail',
  template:`    
    <table class="table" *ngIf="member">
      <thead>
      <tr>
        <td>ID</td>
        <td>Name</td>
        <td>Email</td>
        <td>Phone number</td>
        <td>Account Code</td>
        <!--<td>-->
          <!--<a [routerLink]="['/member-list',member.accountCode]">View More Detail</a>-->
        <!--</td>-->
      </tr> 
      </thead>
      <tbody>
      <tr>
      <tr>
        <td>{{member.id}}</td>
        <td>{{member.name}}</td>
        <td>{{member.emailAddress}}</td>
        <td>{{member.phoneNr}}</td>
        <td>{{member.accountCode}}</td>
        <td>
      </tr>
      </tbody>
    </table>
    <a class="btn btn-default" [routerLink]="['/searchbookonmap']">Go back</a>
    
  `
})
export class MemberDetailComponent implements OnInit, OnDestroy
{
  private  accountCode:string;
  private  subscription:Subscription;
  private member:any;
  constructor(private memberservice:MemberService,private router:Router, private activatedRoute:ActivatedRoute)
  {

  }
  ngOnInit()
  {
    this.subscription=this.activatedRoute.params.subscribe(
      params=>{
        this.accountCode=params['accountCode'];
      }
    );
    this.memberservice.GetMemberByCode(this.accountCode).subscribe(
      (data)=>{
        this.member=data;
      }
    )
  }

  GotoEmployee()
  {
    this.router.navigate(['SearchBookOnMapComponent']);
  }
  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }
}
