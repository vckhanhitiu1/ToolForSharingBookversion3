/**
 * Created by khanhvo on 6/29/17.
 */
import {Component} from "@angular/core";
@Component({
  selector:'admin',
  template:`
    <h1>Admin Main Page</h1>
    <nav>
      <a routerLink="./dashboard" routerLinkActive="active">DashBoard</a>
    </nav>
  `
})
export class AdminComponent
{

}
