import {RouterModule, Routes} from "@angular/router";
import {NgModule} from "@angular/core";
import {AuthGuard} from "../../services/auth.guard.service";
import {AdminComponent} from "./admin.component";
import {AdminDashboardComponent} from "./admin-dashboard.component";
/**
 * Created by khanhvo on 6/29/17.
 */

const adminRoutes:Routes=[
  {
    path:'',
    component:AdminComponent,
    canActivate:[AuthGuard],
    children:[
      {path:'dashboard',component:AdminDashboardComponent}
    ]
  }
];
@NgModule({
  imports:[
    RouterModule.forChild(adminRoutes)
  ],
  exports:[
    RouterModule
  ]

})
export class AdminRoutingModule{}
