/**
 * Created by khanhvo on 6/29/17.
 */
import {Component} from "@angular/core";
@Component({
  selector:'admin-dashboard',
  template:`
    <h1>Admin DashBoard</h1>
  `
})
export class AdminDashboardComponent
{

}
