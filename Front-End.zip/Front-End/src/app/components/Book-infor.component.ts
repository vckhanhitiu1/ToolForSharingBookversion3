import {Component, Input} from '@angular/core';
import {Member} from "../models/data/Member.model";
@Component({

	selector:'book-info',
	template:`
	<div>
	<table>
	<thead>
	<tr>
	<td>Book Name</td>
	</tr>
	</thead>
	<tbody *ngIf = "member.ownBooks!=null">
	<tr *ngFor ="let book of member?.ownBooks.books">
	<td>{{book.bookname}}</td>
	</tr>
	</tbody>
	</table>
	</div>
	`
})

export class BookInfoComponent
{
	@Input() member: Member;
}