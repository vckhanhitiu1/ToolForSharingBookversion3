/**
 * Created by Vo on 2/19/2017.
 */
import { Component, OnInit } from '@angular/core'
import { MemberService } from "../services/member.service";
import {Member} from "../models/data/Member.model";
import {Address} from "../models/data/Address.model";
@Component({
  selector: 'member-list',
  template:
  `
<h1>The Member Information</h1>
<table>
<thead>
<tr>
<td>ID</td>
<td>Name</td>
<td>Email</td>
<td>Phone number</td>
<td>Account Code</td>
<td>Country</td>
<td>City/Province</td>
<td>GPS Latitude</td>
<td>GPS Longtitude</td>
  <!--<td>Book Name</td>-->
</tr>
</thead>
<tbody>
<tr *ngFor="let member of members">
<td>{{member.id}}</td>
<td>{{member.name}}</td>
<td>{{member.emailAddress}}</td>
<td>{{member.phoneNr}}</td>
<td>{{member.accountCode}}</td>
<td>{{member.address.country}}</td>
<td>{{member.address.province}}</td>
<td>{{member.address.gpslocation.latitude}}</td>
<td>{{member.address.gpslocation.longtitude}}</td>
<td>
  <a [routerLink]="['/book-list',member.accountCode]">List Books</a>
</td>
  <!--<td>-->
    <!--<table>-->
      <!--<thead>-->
      <!--<tr>-->
        <!--<td>Book Name</td>-->
        <!--<td>Book Image</td>-->
      <!--</tr>-->
      <!--</thead>-->
      <!--<tbody>-->
      <!--<tr *ngFor="let book of member.ownBooks.books">-->
        <!--<td>{{book.bookname}}</td>-->
        <!--<td>-->
<!--<span class="thumbnail">        -->
  <!--<img src="{{book.image}}" height="150px" width="150px">-->
<!--</span></td>-->
      <!--</tr>-->
      <!--</tbody>-->
       <!---->
    <!--</table>-->
  <!--</td>-->
</tr>
</tbody>
</table>
`,
providers:[MemberService]
})
export class MemberComponent implements OnInit {
  public members: Member[];

  constructor(private memberservice: MemberService) {
  }
  ngOnInit() {
    this.memberservice.GetListMember().subscribe((member: Member[]) => { this.members = member });
  }

}
