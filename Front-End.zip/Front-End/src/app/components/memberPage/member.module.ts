/**
 * Created by khanhvo on 6/30/17.
 */
import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {MemberHomePageComponent} from "./member_hompage.component";
import {MemberRoutingModule} from "./member-routing.module";
@NgModule({
  imports:[
    CommonModule,
    MemberRoutingModule

  ],
  declarations:[
    MemberHomePageComponent
  ]
})
export class MemberModule{

}
