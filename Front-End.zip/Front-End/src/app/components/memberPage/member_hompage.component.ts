/**
 * Created by khanhvo on 6/29/17.
 */
import {Component, OnDestroy, OnInit} from "@angular/core";
import {Subscription} from "rxjs/Subscription";
import {MemberService} from "../../services/member.service";
import {ActivatedRoute, Router} from "@angular/router";
@Component({
  selector:'memberhomepage',
  template:`
     <table class="table" *ngIf="member">
       <thead>
       <tr>
         <td>Member Name</td>
       </tr>
       </thead>
       <tbody>
       <tr>
         <td>{{member.name}}</td>
       </tr>
       </tbody>
     </table>
  `
})
export class MemberHomePageComponent implements OnInit ,OnDestroy
{
  private email: string;
  private subscription: Subscription;
  private member: any;

  constructor(private memberservice: MemberService,
              private router: Router,
              private activateRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.subscription = this.activateRoute.params.subscribe(
      params => {
        this.email = params['email'];
      }
    );
    this.memberservice.getMemberByEmail(this.email).subscribe(
      (data) => {
        this.member = data;
        console.log(data)
      }
    )

  }
  ngOnDestroy()
  {
    this.subscription.unsubscribe();
  }

}
