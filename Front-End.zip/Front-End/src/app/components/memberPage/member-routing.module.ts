import {RouterModule, Routes} from "@angular/router";
import {AuthGuard} from "../../services/auth.guard.service";
import {NgModule} from "@angular/core";
import {MemberHomePageComponent} from "./member_hompage.component";
/**
 * Created by khanhvo on 6/30/17.
 */
const memberRoutes:Routes=[
  {
    path:'',
    component:MemberHomePageComponent,
    canActivate:[AuthGuard]
  }
  ]
@NgModule({
  imports:[
    RouterModule.forChild(memberRoutes)
  ],
  exports:[
    RouterModule
  ]
})

export class MemberRoutingModule{}
