import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'bs-favorite',
  template:
  `
    <div class="fave"
         [title]="favorite"
         (click)="onClick()">
      <h4>Add to Favorite: <i class="fa fa-heart" [class.faveSelected]="isSelected(fave)">
      </i>{{ reviews }}</h4>
    </div>
  `
})

export class FavoriteComponent {

  fave: boolean = false;

  @Input() favorite: string;
  @Input() reviews: number;
  @Output() favoriteClicked: EventEmitter<string> = new EventEmitter<string>();

  onClick(): void {
    this.favoriteClicked.emit(`The favorite ${this.favorite} was saved`);
    this.fave = !this.fave;
  }

  isSelected(fave: boolean): boolean {
    if(!fave || !this.fave) {
      return false;
    }
    if(fave) {
      return true;
    }
  }
}
