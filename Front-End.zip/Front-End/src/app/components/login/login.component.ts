import {Component, Input, OnInit} from "@angular/core";
import {Login} from "../../models/data/login.model";
import {AuthenticationService} from "../../services/authentication.service";
import {ActivatedRoute, Router,NavigationExtras} from "@angular/router";
import {AlertService} from '../../services/alert.service';
import {LogInService} from "../../services/login.service";
import { Http } from '@angular/http';
import { contentHeaders } from '../../technical/headers';
import {AuthGuard} from "../../services/auth.guard.service";
@Component({
	selector:"log-in",
	template:
  `
  <div class="login jumbotron center-block">
  <h1>Login</h1>
  <p>{{message}}</p>

  <form #loginForm="ngForm" (ngSubmit)="CheckLogIn(loginForm.value)">
  <div class="form-group">
    <label for="email">Email</label>
          <input type="email" class="form-control" name="email" placeholder="Enter your email" #email ngModel required>
  </div>
  <div class="form-group">
    <label for="password">Password</label>
          <input type="password" class="form-control" password="password"  name="password" placeholder="Enter your password" #password  ngModel required>
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
    <a [routerLink]="['/register']">Click here to Signup</a>
    <button (click)="logout()" *ngIf="loginservice.isLoggedIn">Logout</button>

</form>
</div>
  `,
  providers:[LogInService,AuthGuard]
  // require('./login.component.html')
})
export class LoginComponent implements OnInit
{
	 private logins: Login[];

  message: string;

   constructor(public router: Router, public http: Http,  private loginservice:LogInService) {
     this.setMessage();
}

setMessage()
{
      this.message = 'Logged ' + (this.loginservice.isLoggedIn ? 'in' : 'out');
}

ngOnInit()
{
  this.loginservice.GetAccount().subscribe((login:Login[])=>{
    this.logins=login
    console.log(login);
  })
}

CheckLogIn(value:any)
{
  console.log(value);
  for(let login of this.logins)
  {
    if(value.email==login.email && value.password==login.password)
    {
      this.message = 'Trying to log in ...';

      this.loginservice.login().subscribe(() => {
        this.setMessage();
        if (this.loginservice.isLoggedIn = true) {

          this.router.navigate(['memberhomepage',value.email]);
        }
      });
    }
    else if (value.username== 'admin' && value.password =='admin')
      {
        this.message = 'Trying to log in ...';

        this.loginservice.login().subscribe(() => {
          this.setMessage();
          if (this.loginservice.isLoggedIn = true) {

            let redirect = this.loginservice.redirectUrl ? this.loginservice.redirectUrl : '/admin';

            this.router.navigate([redirect]);
          }
        });
    }
    else {
      console.error("wrong username or password");
    }
  }
  // this.onLoginSubmit(value);

}

login() {
    this.message = 'Trying to log in ...';

    this.loginservice.login().subscribe(() => {
      this.setMessage();
      if (this.loginservice.isLoggedIn = true) {

        let redirect = this.loginservice.redirectUrl ? this.loginservice.redirectUrl : '/admin';

        this.router.navigate([redirect]);
      }
    });
  }

 logout() {
    this.loginservice.logout();
    this.setMessage();
  }

}
