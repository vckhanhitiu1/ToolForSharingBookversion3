/**
 * Created by Vo on 2/22/2017.
 */

import{Component, OnInit, ChangeDetectorRef ,ViewChild  } from '@angular/core';
import {RouterModule, Routes, Router} from '@angular/router';
import {BookService} from '../services/book.service';
import {ImageCropperComponent, CropperSettings, Bounds} from 'ng2-img-cropper';
import {LogInService} from "../services/login.service";
import {Book} from "../models/data/Book.model";
import {BookOCRService} from "../services/book-ocr.service";
import {Http, RequestOptions} from "@angular/http";
import {Observable} from "rxjs/Observable";
@Component({
  selector:'ocr-app',
  template:
  `
    <h4> Book Registration Form </h4>
    <form>

      <div class="form-group">
        <label>Book Name</label>
        <!--<div class="file-upload">-->
        <!--<span class="text">upload</span> -->
        <input  type="url" name="bookname" required
        #bookname
        [(ngModel)]="book.bookname" 
        > 
        {{book.bookname}}

        <!--</div>-->
        <!--<img-cropper #cropper [image]="book" [settings]="cropperSettings1" (onCrop)="cropped($event)"></img-cropper>-->
        <!--<br>-->
        <!--<span *ngIf="book.image" >-->
          <!--<img src="data:image/jpeg;base64,{{book.bookname}}"  [width]="cropperSettings1.croppedWidth"-->
               <!--[height]="cropperSettings1.croppedHeight">-->
          <!--<img [src]="book.image"-->
               <!--[width]="cropperSettings1.croppedWidth"-->
               <!--[height]="cropperSettings1.croppedHeight">-->
      <!--</span>-->
      </div>
      <div class="form-group">
        <label>ISBN</label>
        <!--<div class="file-upload">-->
          <!--<span class="text">upload</span>-->
          <input  type="url" name="isbn" required
                  #isbn
                  [(ngModel)]="book.isbn">
        {{book.isbn}}
        <!--</div>-->
        <!--<img-cropper #cropper [image]="book" [settings]="cropperSettings1" (onCrop)="cropped($event)"></img-cropper>-->
        <!--<br>-->
        <!--<span *ngIf="book.image" >-->
           <!--<img src="data:image/jpeg;base64,{{book.isbn}}" -->
                <!--[width]="cropperSettings1.croppedWidth"-->
                <!--[height]="cropperSettings1.croppedHeight">-->
          
          <!--<img [src]="book.image"-->
               <!--[width]="cropperSettings1.croppedWidth"-->
               <!--[height]="cropperSettings1.croppedHeight">-->
      <!--</span>-->
      </div>
      <div class="form-group">
        <label>Book Edition</label>
        <input type="number"  class="form-control" name="bookedition" required #bookedition [(ngModel)]="book.edition">
      </div>
      <div class="form-group">
        <label for="copyright">CopyRight</label>
        <input type="Date"  class="form-control" name="copyright" required #copyright [(ngModel)]="book.copyright">
      </div>
      <div class="form-group">
        <label for="booktype">Book Type</label>
        <select class="form-control" name="booktype" required #booktype [(ngModel)]="book.booktype">
          <option>SCIENCE</option>
          <option>ACTION</option>
          <option>ROMANCE</option>
          <option>HORROR</option>
          <option>MYSTERY</option>
        </select>
      </div>
      <div class="form-group" >
        <label>Book Status</label>
        <select class="form-control" name="bookstatus"  require #bookstatus [(ngModel)]="book.status">
          <option>PHYSICALBOOK</option>
          <option>SOFTBOOK</option>
        </select>
      </div>

      <div class="form-group">
        <label>Description</label>
        <input type="text"  class="form-control" name="description" required [(ngModel)]="book.description">
      </div>
      <div class="form-group">
        <label>Author</label>
        <input type="text"  class="form-control" name="authors" required [(ngModel)]="book.authors">
      </div>
      <label>Book Upload</label>
      <div class="form-group">
        <input type="file" name="image" required
               (change)="fileChange(image)"
               #image
               [(ngModel)]="book.image"
        />
      </div>
      <div>
        <img [attr.src]='book.image' alt=""  height="150px" width="150px"/>
      </div>
    
      <tr>
        <td colspan="2">
          <button type="button" class="btn btn-primary" (click)="SaveForm()">Save</button>
          <button type="button" class="btn btn-success" routerLink="/">Cancel</button>
        </td>
      </tr>
    </form>

  `,
  providers:[BookService]
})
export class OcrComponent
{



  public book: any;

  cropperSettings1:CropperSettings;
  croppedWidth:number;
  croppedHeight:number;



  @ViewChild('cropper', undefined) cropper:ImageCropperComponent;

  constructor(private changeDetectorRef: ChangeDetectorRef,private bookOCRservice:BookOCRService,
              private router:Router, private http:Http
              ) {


    this.cropperSettings1 = new CropperSettings();
    this.cropperSettings1.width = 200;
    this.cropperSettings1.height = 200;

    this.cropperSettings1.croppedWidth = 200;
    this.cropperSettings1.croppedHeight = 200;

    this.cropperSettings1.canvasWidth = 500;
    this.cropperSettings1.canvasHeight = 300;

    this.cropperSettings1.minWidth = 10;
    this.cropperSettings1.minHeight = 10;



    this.cropperSettings1.cropperDrawSettings.strokeColor = 'rgba(255,255,255,1)';
    this.cropperSettings1.cropperDrawSettings.strokeWidth = 2;



    this.book={}

  }



  GotoBooKInformation()
  {
    this.router.navigate(['/']);
  }

  cropped(bounds:Bounds) {
    this.croppedHeight =bounds.bottom-bounds.top;
    this.croppedWidth = bounds.right-bounds.left;
  }


  fileChangeListener($event) {
    var image:any = new Image();
    var file:File = $event.target.files[0];
    var myReader:FileReader = new FileReader();
    var that = this;
    myReader.onloadend = function (loadEvent:any) {
      image.src = loadEvent.target.result;
      that.cropper.setImage(image);

    };

    myReader.readAsDataURL(file);
  }


  SaveForm()
  {
    this.bookOCRservice.PostBookOCR(this.book).subscribe(response=>{
      if(response)
      {
        alert('Add Success');
        this.router.navigate(['/']);
      }
    })

  }
}
