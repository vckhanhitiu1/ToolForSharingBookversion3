/**
 * Created by Vo on 6/1/2017.
 */
import {Component, EventEmitter, Input, Output} from "@angular/core";
import {OwnBookToolbarDisplayOptions} from "../services/resources.service";
import {Action, TOOLBAR_ACTION_TYPE} from "../models/data/toolbar-action";
@Component({
  selector:'ownbook-toolbar-display',
  template:`    
    <i *ngIf="!displayOption.hideEditButton" class="fa fa-pencil-square-o fa-lg" 
       aria-hidden="true" ngbTooltip="Edit" (click)="actionDispatched({type: actionTypeEdit})"></i>
  `
})
export class OwnBookToolBarDisplay
{
  @Input() displayOption: OwnBookToolbarDisplayOptions;
  @Output() onActionDispatch: EventEmitter<Action> = new EventEmitter<Action>();

  private actionTypeEdit = TOOLBAR_ACTION_TYPE.EDIT;

  private actionDispatched(action: Action) {
    this.onActionDispatch.emit(action);
  }
}
