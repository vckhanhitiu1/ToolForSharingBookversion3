/**
 * Created by khanhvo on 6/18/17.
 */
import {Component, keyframes, OnInit} from "@angular/core";
import {SearchBookOnMapService} from "../services/searchbook_onmap.service";
import {BookOwner} from "../models/data/BookOwner.model";
import {GOOGLE_MAP} from "../constant/app.constants";
@Component({
  selector:'search-book-on-map',
  template:`
    <div>
      <div class="row">
        <div class="col-md-12">
          <div class="col-md-4">
            <input type="text" [(ngModel)]="keyword" name="keyword" />
            <button (click)="Search()">Search</button>

          </div>
        </div>
      </div>
      <sebm-google-map
        [latitude]="currentLocation.latitude"
        [longitude]="currentLocation.longitude"
        [zoom]="zoom_level"
        [streetViewControl]="false"
        (mapClick)="deselectedMarker()">
        <member-marker-display *ngFor="let bookowner of bookowners"
          [members]="bookowner.memberList"
          (onMarkerClick)="memberSelected($event)">
        </member-marker-display>
      </sebm-google-map>
      <table class="table">
        <thead>
        <tr>
          <td>Book ISBN</td>
          <td>Book Name</td>
          <td>BookOwner</td>
        </tr>
        </thead>
        <tbody>
        <tr *ngFor="let bookowner of bookowners">
          <td>{{bookowner.isbn}}</td>
          <td>{{bookowner.bookname}}</td>
          <td>
            <table>
              <thead>
              <tr>
                <td>BookOwner Name</td>
                <td>BookOwner Code</td>
                <td>City</td>
                <td>latitude</td>
                <td>longitude</td>
              </tr>
              </thead>
              <tbody>
              <tr *ngFor = "let member of bookowner.memberList">
                <td>{{member.name}}</td>
                <td>{{member.accountCode}}</td>
                <td>{{member.address.toString()}}</td>
                <td>{{member.address.gpslocation.latitude}}</td>
                <td>{{member.address.gpslocation.longtitude}}</td>
                <td>
                  <a [routerLink]="['/member-detail',member.accountCode]">Show Detail</a>
                </td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        </tbody>
      </table>
    </div>
  `
})

export class SearchBookOnMapComponent implements OnInit{

  public bookowners:any[];
  private keyword:string;
  private currentLocation=GOOGLE_MAP.HCM_LOCATION;
  private zoom_level = GOOGLE_MAP.DEFAULT_ZOOM_LEVEL;

  constructor(private searchbookonmapservice: SearchBookOnMapService)
  {}

  ngOnInit()
  {
    this.searchbookonmapservice.GetListBookOwner()
      .subscribe((bookowners:BookOwner[])=> {this.bookowners=bookowners});
  }

  Search()
  {
    this.searchbookonmapservice.Search(this.keyword)
      .subscribe((response:any)=>{
      this.bookowners= response;
        console.log(response);
      }, error => {
        console.log(error);

      });
  }
}
