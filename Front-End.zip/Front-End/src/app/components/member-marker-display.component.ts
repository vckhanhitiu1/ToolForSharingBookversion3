import {Component, EventEmitter, Input, Output} from "@angular/core";
import {Member} from "../models/data/Member.model";
import { SebmGoogleMap, SebmGoogleMapMarker,  AgmCoreModule} from 'angular2-google-maps/core';
import {PlacesAutoCompleteService} from "../services/places-auto-complete.service";

@Component({
    selector:'member-marker-display',
    template:`
    <sebm-google-map-marker 
        *ngFor="let member of members"
        [latitude] = "member.address.gpslocation.latitude"
        [longitude]= "member.address.gpslocation.longtitude"
        (markerClick) = "markerClicked(member)"
    >  
    </sebm-google-map-marker>
    `
})
export class MemberMarkerDisplayComponent
{
    @Input() members: Member[];
    @Output() onMarkerClick = new EventEmitter();

    private markerClicked(member:Member)
    {
      this.onMarkerClick.emit(member);
    }


}
