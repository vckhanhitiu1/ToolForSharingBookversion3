/**
 * Created by Vo on 6/1/2017.
 */

import {Component, Input} from '@angular/core'
import {Member} from "../models/data/Member.model";
@Component({
  selector:'member-basic-display',
  template:`
        <div class="lead shorten-long-text">
      {{member?.name}} ({{member?.accountCode}})
    </div>
        <div class="shorten-long-text">{{member?.address.toString()}}</div>
  `
})
export class MemberBasicDisplay
{
  @Input() member:Member;


}


