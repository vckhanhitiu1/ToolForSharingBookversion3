import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {routing, RootComponent} from './routes';
import {FormsModule} from '@angular/forms';
import {CommonModule, APP_BASE_HREF} from '@angular/common';
import { AgmCoreModule } from 'angular2-google-maps/core';
import {AppComponent} from "./components/app.component";
import {HttpModule} from '@angular/http';
import {OcrComponent} from'./components/ocr.component';
import {MapComponent} from './components/map.component';
import {HomeComponent} from './components/home.component';
import {BookService} from './services/book.service';
import {MemberService} from './services/member.service';
import {BookComponent} from './components/book.component';
import {MemberComponent} from './components/member.component';
import {MemberMarkerDisplayComponent} from './components/member-marker-display.component';
import {BookRegistrationComponent} from './components/bookregistration.component';
import {MemberRegitrationFormComponent} from './components/memberregistration.component';
import {BookDetailComponent} from './components/bookdetail.component';
import {NotFoundComponent} from './components/notfound.component';
import {GoogleMapsGeocodingService} from './services/google-maps-geocoding.service';
import {PlacesAutoCompleteService} from './services/places-auto-complete.service';
import {ImageCropperComponent} from 'ng2-img-cropper';
import {MemberBasicDisplay} from './components/member-basic-display.component';
import {OwnBookDataDisplay} from './components/ownbook-data-display';
import {OwnBookToolBarDisplay} from './components/ownbook-toolbar-display.component';
import {ResourceService} from './services/resources.service';
import {BookInfoComponent} from './components/Book-infor.component';
import {LoginComponent} from './components/login/login.component';
import {RegisterComponent} from './components/register/register.component';
import {RegisterService} from './services/register.service';
import {AuthenticationService} from './services/authentication.service';
import {AlertService} from './services/alert.service';
import {SearchBookComponent} from './components/searchBook.component';
import {SearchService} from './services/search.service';
import {LogInService} from './services/login.service';
import {AuthGuard} from './services/auth.guard.service';
import {SearchBookOnMapComponent} from "./components/searchbook_onmap.component";
import {SearchBookOnMapService} from "./services/searchbook_onmap.service";
import {BookOwnerRegistrationComponent} from "./components/bookowner_registration.component";
import {MemberDetailComponent} from "./components/member_detail.component";
import {GetOcrComponent} from "./components/getocr.component";
import {FavoriteComponent} from "./components/favorite.component";
import {AdminModule} from "./components/admin/admin.module";
import {MemberModule} from "./components/memberPage/member.module";
import {BookOCRService} from "./services/book-ocr.service";
@NgModule({
  imports: [
    BrowserModule,
    routing,
    CommonModule,
    FormsModule,
    AdminModule,
    MemberModule,
    HttpModule,
    AgmCoreModule.forRoot({
      apiKey:'AIzaSyACGaDxyjAqy8uZMSq7uGGqPcinO_Z0IsU ',
      libraries: ["places"]
    }),
  ],
  declarations: [
    AppComponent,
    MapComponent,
    HomeComponent,
    OcrComponent,
    BookComponent,
    MemberComponent,
    MemberMarkerDisplayComponent,
    BookRegistrationComponent,
    MemberRegitrationFormComponent,
    BookDetailComponent,
    NotFoundComponent,
    ImageCropperComponent,
    MemberBasicDisplay,
    OwnBookDataDisplay,
    OwnBookToolBarDisplay,
    BookInfoComponent,
    LoginComponent,
    RegisterComponent,
    SearchBookComponent,
    SearchBookOnMapComponent,
    BookOwnerRegistrationComponent,
    MemberDetailComponent,
    GetOcrComponent,
    FavoriteComponent
  ],
  providers:[
    MemberService,
    BookService,
    GoogleMapsGeocodingService,
    PlacesAutoCompleteService,
    ResourceService,
    AuthenticationService,
    RegisterService,
    AlertService,
    SearchService,
    AuthGuard,
    LogInService,
    SearchBookOnMapService,
    BookOCRService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
