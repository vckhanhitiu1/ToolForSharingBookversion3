import {Injector} from "@angular/core";
import {Http, RequestOptions, Response, Headers, URLSearchParams} from "@angular/http";
import {Observable} from "rxjs";
import Helper from "../technical/helper";
import {SearchByCriteria} from "../models/search/search-by-criteria.model";
/**
 * Created by Vo on 2/17/2017.
 */

export default class GenericService
{
  protected _http;

  protected BASE_URL = 'http://localhost:8080/ThesisProject/api/';


  constructor(injector:Injector) {
    this._http=injector.get(Http);
  }

  protected search(searchByCriteria: SearchByCriteria): Observable<any> {
    let encodedParam = Helper.generateSearchByQueryParam(searchByCriteria);
    let queryParams = new URLSearchParams(encodedParam);
    let option = new RequestOptions({
      search: queryParams
    });
    return this.get(option);
  }
  protected get(options?: RequestOptions): Observable<any> {
        return this.request(options)
            .map(this.extractData);
    }

    protected post(data: Object): Observable<Response> {
        return this.request(this.defaultPostOptions(data));
    }


    protected put(data:Object): Observable<Response>
    {
        return this.request(this.defaultPutOptions(data));
    }

 protected defaultRequestOptions(): RequestOptions {
        return new RequestOptions({
            headers: this.defaultGetHeaders()
        })
    }

protected request(options?: RequestOptions): Observable<Response> {
        return this._http.request(this.BASE_URL, this.defaultRequestOptions().merge(options));
    }

   private convertObjectToJson(data: Object) {
        return JSON.stringify(data);
    }
        protected defaultGetHeaders(): Headers {
        return new Headers({
            'Accept': 'application/json'
        });
    }

     protected defaultPostHeaders(): Headers {
        return new Headers({
            'Content-Type': 'application/json'
        });
    }

    protected defaultPutHeaders(): Headers {
        return new Headers({
            'Content-Type': 'application/json'
        });
    }

    protected extractData(resp: Response) : Array<any>{
        return resp.json();
    }


     private defaultPostOptions(data: Object) {
        return new RequestOptions({
            method: 'POST',
            url: this.BASE_URL,
            body: this.convertObjectToJson(data),
            headers: this.defaultPostHeaders()
        });
    }

    private defaultPutOptions(data: Object) {
        return new RequestOptions({
            method: 'PUT',
            url: this.BASE_URL,
            body: this.convertObjectToJson(data),
            headers: this.defaultPutHeaders()
        });
    }

}

