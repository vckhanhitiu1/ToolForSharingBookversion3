import {Injectable, Injector} from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import {Login} from "../models/data/login.model";
import GenericService from "./generic.service";
import {Observable} from "rxjs/Observable";

@Injectable()
export class LogInService extends  GenericService
{

  isLoggedIn =false;

  redirectUrl:string;

   login(): Observable<boolean> {
    return Observable.of(true).delay(1000).do(val => this.isLoggedIn = true);
  }

  logout():void
  {
    this.isLoggedIn=false;
  }



  constructor(injector:Injector, _http:Http)
  {
    super(injector);
    this.BASE_URL+='users/showall';
  }


    GetAccount():Observable<Login[]>
    {
      return this.get();
    }

}
