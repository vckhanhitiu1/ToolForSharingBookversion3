import {MapsAPILoader} from "angular2-google-maps/core";
import {NgZone, Injectable} from "@angular/core";
import {Address} from "../models/data/Address.model";
import {google} from '@types/google-maps';
import PlaceResult = google.maps.places.PlaceResult;
import {GoogleMapsGeocodingService} from "./google-maps-geocoding.service";
import {Subject} from "rxjs";

@Injectable()
export class PlacesAutoCompleteService {
    private autoComplete;
    private addresses = new Subject<Address>();
    private status = new Subject<google.maps.places.PlacesServiceStatus>();
    observableStatus$ = this.status.asObservable();
    observableAddress$ = this.addresses.asObservable();

    constructor(private geocodingService: GoogleMapsGeocodingService,
                private _loader: MapsAPILoader,
                private _zone: NgZone) {}

    public turnOnSuggestion(elementID: string) {
        this._loader.load().then(() => {
            this.autoComplete = new google.maps.places.Autocomplete(<HTMLInputElement>document.getElementById(elementID), {});
            this.autoComplete.setComponentRestrictions({'country': 'vn'});
            google.maps.event.addListener(this.autoComplete, 'place_changed', () => {
                this._zone.run(() => {
                    let place = this.autoComplete.getPlace();
                    if (place != null) {
                        let address = this.geocodingService.convertPlaceResultToAddressObject(place.address_components, place.geometry);
                        this.addresses.next(address);
                    }
                });
            });
        });
    }

    public turnOnStatusSubscriptions(elementID: string, keywords: string) {
        let autocompleteService = new google.maps.places.AutocompleteService();
        autocompleteService.getQueryPredictions({input: keywords}, (predictions, status) => {
            this.status.next(status);
        });
    }
}