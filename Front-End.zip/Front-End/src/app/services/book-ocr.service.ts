import {Injectable, Injector} from "@angular/core";
import GenericService from "./generic.service";
import {Http, Response} from "@angular/http";
import {BookOCR} from "../models/data/book-ocr.model";
import {Observable} from "rxjs/Observable";
/**
 * Created by khanhvo on 7/1/17.
 */
@Injectable()
export class BookOCRService extends GenericService
{

  constructor(injector: Injector,  public _http:Http) {
    super(injector);
    this.BASE_URL += 'bookocr';

  }

  GetListBookOCR():Observable<BookOCR[]>{
    return this.get();
  }
  PostBookOCR(bookOCR:BookOCR):Observable<Response>{
    return this.post(bookOCR);
  }



}
