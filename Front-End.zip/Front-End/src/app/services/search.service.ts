import {Injectable, Injector} from "@angular/core";
import GenericService from "./generic.service";
import {Observable} from "rxjs/Observable";
import {Http} from "@angular/http";
/**
 * Created by Vo on 6/11/2017.
 */
@Injectable()
export class SearchService extends GenericService
{
  constructor(injector:Injector, _http:Http)
  {
    super(injector);
  }

  Search(keyword:String):Observable<any[]>
  {
    return this._http.get(this.BASE_URL + keyword).map(
      (response:Response) => response.json()
    )
  }
}
