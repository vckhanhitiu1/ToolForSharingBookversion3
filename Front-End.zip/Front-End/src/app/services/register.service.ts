import {Injectable, Injector} from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import {Login} from "../models/data/login.model";
import GenericService from "./generic.service";
import {Observable} from "rxjs/Observable";
/**
 * Created by Vo on 6/6/2017.
 */
@Injectable()
export class RegisterService extends GenericService
{
  constructor(injector:Injector, private http:Http)
  {super(injector);
    this.BASE_URL+='users/addnew';
  }

  // create(loginuser:Login)
  // {
  //   return this.http.post(this.BASE_URL+='users/login',loginuser,this.jwt()).map((response:Response)=>response.json());
  // }

  PostNewAccount(login:Login):Observable<Response>
  {
    return this.post(login);
  }
}
