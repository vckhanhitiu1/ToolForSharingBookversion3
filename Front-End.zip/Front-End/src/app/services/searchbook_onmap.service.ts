import GenericService from "./generic.service";
import {BookOwner} from "../models/data/BookOwner.model";
import {Injectable, Injector} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {Http, Response} from "@angular/http";
/**
 * Created by khanhvo on 6/18/17.
 */

@Injectable()
export class SearchBookOnMapService extends GenericService
{
  private bookowners: BookOwner[];

  constructor(injector:Injector, private http:Http)
  {
    super(injector);
    this.BASE_URL+='bookowners';
  }

  GetListBookOwner():Observable<BookOwner[]>
  {
    return this.get();
  }

  Search(keyword: string): Observable<any[]> {
    return this._http.get(this.BASE_URL +"/"+ keyword).map((response: Response) => response.json())
  }

  PostBookOwner(bookowner:BookOwner): Observable<Response>
  {
    return this.post(bookowner);
  }

}
