import { Injectable } from '@angular/core';
import {
  CanActivate, Router,
  ActivatedRouteSnapshot, Route,
  RouterStateSnapshot, CanLoad
} from '@angular/router';
import { tokenNotExpired } from 'angular2-jwt';
import {LogInService} from './login.service';
import {Observable} from "rxjs/Observable";

@Injectable()
export class AuthGuard implements CanActivate, CanLoad {

  constructor(private router: Router, private loginService:LogInService) {}


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    // let url: string = state.url;
    //
    // return this.checkLogin(url);
   let url:string = state.url;
   return this.checkLogin(url);
  }

  canLoad(route: Route): boolean {

    if(this.loginService.isLoggedIn) {
      return true
    }
    else {
      this.router.navigate(['/login']);
      return false;
    }
  }

  checkLogin(url: string): boolean {
    if (this.loginService.isLoggedIn) { return true; }

    // Store the attempted URL for redirecting
    this.loginService.redirectUrl = url;


    // Navigate to the login page with extras
    this.router.navigate(['/login']);
    return false;
  }

}
