import GenericService from "./generic.service";
import {Member} from "../models/data/Member.model";
import {Injectable, Injector} from "@angular/core";
import {Http, Response} from "@angular/http";
import {Observable} from "rxjs/Observable";
import "rxjs/add/operator/map"
import {SearchCriteria} from "../models/search/search-criteria.model";
import {MemberSearchField} from "../models/search/search-field.model";
import {ComparisonExpression} from "../models/search/comparison-expression.model";
import {SearchByCriteria} from "../models/search/search-by-criteria.model";
/**
 * Created by Vo on 2/19/2017.
 */

@Injectable()
export class MemberService extends GenericService
{
  private members: Array<Member>;

  constructor(injector:Injector, public _http:Http) {
    super(injector)
    this.BASE_URL +='members';
  }

  public getMemberWithDisplayMode(showAll?: boolean): Observable<Member[]>
  {
    if(showAll === true)
    return this.GetListMember();
  }

  GetListMember():Observable<Member[]>{
    return this._http.get(this.BASE_URL).map((response:Response)=>response.json());
  }

  PostMember(member:Member): Observable<Response>
  {
  	return this.post(member);
  }

  GetMemberByCode(accountCode:string):Observable<any>
  {
    return this._http.get(this.BASE_URL+'/'+ accountCode).map((response:Response)=> response.json());
  }


  PutMember(member:Member): Observable<Response>
  {
    return this.put(member);
  }
  getMemberByEmail(email:string): Observable<Member[]>
   {
     let criterias: Array<SearchCriteria> = [];
     const searchByEmail = new SearchCriteria({
       field:MemberSearchField[MemberSearchField.EMAIL],
       expression:ComparisonExpression.EQUAL,
       value: email

     });
     criterias.push(searchByEmail);
     let searchByCriterias = new SearchByCriteria(criterias);

     return this.search(searchByCriterias);
   }

}
