
import{SearchByCriteria} from '../models/search/search-by-criteria.model';

export default class Helper
{
  static generateSearchByQueryParam(searchByCriteria: SearchByCriteria): string {
    let searchByJson = JSON.stringify(searchByCriteria);
    return `searchBy=${searchByJson}`;
  }
}
